"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_black_formats_source_deterministically():
    import black

    formatted = black.format_str("items=[1,2,3]\n", mode=black.Mode())
    assert formatted == "items = [1, 2, 3]\n"
