"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_black_formats_source_deterministically():
    import black

    formatted = black.format_str("items=[1,2,3]\n", mode=black.Mode())
    assert formatted == "items = [1, 2, 3]\n"
