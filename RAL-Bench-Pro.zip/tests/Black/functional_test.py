from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'black'
CORE_MODULES = ['black', 'black.resources', 'black.brackets', 'black.cache', 'black.comments', 'black.concurrency']
PUBLIC_SYMBOLS = [('black', 'WriteBack'), ('black', 'read_pyproject_toml'), ('black', 'spellcheck_pyproject_toml_keys'), ('black', 'target_version_option_callback'), ('black', 'enable_unstable_feature_callback'), ('black', 're_compile_maybe_verbose'), ('black', 'validate_regex'), ('black', 'main'), ('black', 'get_sources'), ('black', 'reformat_code'), ('black', 'reformat_one'), ('black', 'format_file_in_place'), ('black', 'format_stdin_to_stdout'), ('black', 'check_stability_and_equivalence'), ('black', 'format_file_contents'), ('black', 'format_cell'), ('black', 'validate_metadata'), ('black', 'format_ipynb_string')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_black_formats_source_deterministically():
    import black

    formatted = black.format_str("items=[1,2,3]\n", mode=black.Mode())
    assert formatted == "items = [1, 2, 3]\n"
