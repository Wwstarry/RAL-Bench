from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'parsimonious'
CORE_MODULES = ['parsimonious', 'parsimonious.exceptions', 'parsimonious.expressions', 'parsimonious.grammar', 'parsimonious.nodes', 'parsimonious.utils']
PUBLIC_SYMBOLS = [('parsimonious.exceptions', 'ParsimoniousError'), ('parsimonious.exceptions', 'ParseError'), ('parsimonious.exceptions', 'LeftRecursionError'), ('parsimonious.exceptions', 'IncompleteParseError'), ('parsimonious.exceptions', 'VisitationError'), ('parsimonious.exceptions', 'BadGrammar'), ('parsimonious.exceptions', 'UndefinedLabel'), ('parsimonious.expressions', 'Expression'), ('parsimonious.expressions', 'Literal'), ('parsimonious.expressions', 'TokenMatcher'), ('parsimonious.expressions', 'Regex'), ('parsimonious.expressions', 'Compound'), ('parsimonious.expressions', 'Sequence'), ('parsimonious.expressions', 'OneOf'), ('parsimonious.expressions', 'Lookahead'), ('parsimonious.expressions', 'Quantifier'), ('parsimonious.expressions', 'is_callable'), ('parsimonious.expressions', 'expression')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_peg_grammar_parses_repeated_tokens():
    from parsimonious.grammar import Grammar

    grammar = Grammar('word = ~"[a-z]+"\nphrase = word (" " word)*')
    node = grammar["phrase"].parse("hello world")
    assert node.text == "hello world"
