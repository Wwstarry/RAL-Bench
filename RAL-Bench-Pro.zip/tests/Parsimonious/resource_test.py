"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_peg_grammar_parses_repeated_tokens():
    from parsimonious.grammar import Grammar

    grammar = Grammar('word = ~"[a-z]+"\nphrase = word (" " word)*')
    node = grammar["phrase"].parse("hello world")
    assert node.text == "hello world"
