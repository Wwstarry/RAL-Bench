"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_peg_grammar_parses_repeated_tokens():
    from parsimonious.grammar import Grammar

    grammar = Grammar('word = ~"[a-z]+"\nphrase = word (" " word)*')
    node = grammar["phrase"].parse("hello world")
    assert node.text == "hello world"
