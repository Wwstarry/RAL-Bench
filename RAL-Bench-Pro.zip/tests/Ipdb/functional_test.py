from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'ipdb'
CORE_MODULES = ['ipdb', 'ipdb.__main__', 'ipdb.stdout']
PUBLIC_SYMBOLS = [('ipdb.__main__', 'ConfigFile'), ('ipdb.__main__', 'wrap_sys_excepthook'), ('ipdb.__main__', 'set_trace'), ('ipdb.__main__', 'get_context_from_config'), ('ipdb.__main__', 'get_config'), ('ipdb.__main__', 'post_mortem'), ('ipdb.__main__', 'pm'), ('ipdb.__main__', 'run'), ('ipdb.__main__', 'runcall'), ('ipdb.__main__', 'runeval'), ('ipdb.__main__', 'launch_ipdb_on_exception'), ('ipdb.__main__', 'main'), ('ipdb.stdout', 'update_stdout'), ('ipdb.stdout', 'sset_trace'), ('ipdb.stdout', 'spost_mortem'), ('ipdb.stdout', 'spm'), ('ipdb.stdout', 'slaunch_ipdb_on_exception')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_ipdb_conditional_trace_is_noop_when_disabled():
    import ipdb

    assert ipdb.set_trace(cond=False) is None
