"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_ipdb_conditional_trace_is_noop_when_disabled():
    import ipdb

    assert ipdb.set_trace(cond=False) is None
