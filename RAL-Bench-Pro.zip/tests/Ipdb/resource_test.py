"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_ipdb_conditional_trace_is_noop_when_disabled():
    import ipdb

    assert ipdb.set_trace(cond=False) is None
