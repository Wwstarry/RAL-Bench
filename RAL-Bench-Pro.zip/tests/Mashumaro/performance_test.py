"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mashumaro_serializes_and_deserializes_dataclasses():
    from dataclasses import dataclass
    from mashumaro.mixins.dict import DataClassDictMixin

    @dataclass
    class User(DataClassDictMixin):
        name: str
        age: int

    assert User.from_dict({"name": "Ada", "age": 36}).to_dict() == {"name": "Ada", "age": 36}
