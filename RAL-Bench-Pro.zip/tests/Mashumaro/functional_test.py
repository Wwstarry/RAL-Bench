from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mashumaro'
CORE_MODULES = ['mashumaro', 'mashumaro.codecs', 'mashumaro.core', 'mashumaro.jsonschema', 'mashumaro.mixins', 'mashumaro.core.meta']
PUBLIC_SYMBOLS = [('mashumaro.config', 'SerializationStrategyDict'), ('mashumaro.config', 'BaseConfig'), ('mashumaro.dialect', 'Dialect'), ('mashumaro.exceptions', 'MissingField'), ('mashumaro.exceptions', 'ExtraKeysError'), ('mashumaro.exceptions', 'UnserializableDataError'), ('mashumaro.exceptions', 'UnserializableField'), ('mashumaro.exceptions', 'UnsupportedSerializationEngine'), ('mashumaro.exceptions', 'UnsupportedDeserializationEngine'), ('mashumaro.exceptions', 'InvalidFieldValue'), ('mashumaro.exceptions', 'MissingDiscriminatorError'), ('mashumaro.exceptions', 'SuitableVariantNotFoundError'), ('mashumaro.exceptions', 'BadHookSignature'), ('mashumaro.exceptions', 'ThirdPartyModuleNotFoundError'), ('mashumaro.exceptions', 'UnresolvedTypeReferenceError'), ('mashumaro.exceptions', 'BadDialect'), ('mashumaro.helper', 'field_options'), ('mashumaro.types', 'SerializableType')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mashumaro_serializes_and_deserializes_dataclasses():
    from dataclasses import dataclass
    from mashumaro.mixins.dict import DataClassDictMixin

    @dataclass
    class User(DataClassDictMixin):
        name: str
        age: int

    assert User.from_dict({"name": "Ada", "age": 36}).to_dict() == {"name": "Ada", "age": 36}
