"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mashumaro_serializes_and_deserializes_dataclasses():
    from dataclasses import dataclass
    from mashumaro.mixins.dict import DataClassDictMixin

    @dataclass
    class User(DataClassDictMixin):
        name: str
        age: int

    assert User.from_dict({"name": "Ada", "age": 36}).to_dict() == {"name": "Ada", "age": 36}
