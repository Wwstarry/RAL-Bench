"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_arrow_parses_shifts_and_formats_time():
    import arrow

    value = arrow.get("2025-01-02T03:04:05+00:00")
    assert value.shift(days=1).format("YYYY-MM-DD") == "2025-01-03"
    assert value.to("UTC").hour == 3
