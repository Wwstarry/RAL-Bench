"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_arrow_parses_shifts_and_formats_time():
    import arrow

    value = arrow.get("2025-01-02T03:04:05+00:00")
    assert value.shift(days=1).format("YYYY-MM-DD") == "2025-01-03"
    assert value.to("UTC").hour == 3
