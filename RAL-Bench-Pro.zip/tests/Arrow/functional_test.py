from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'arrow'
CORE_MODULES = ['arrow', 'arrow.api', 'arrow.arrow', 'arrow.factory', 'arrow.formatter', 'arrow.locales']
PUBLIC_SYMBOLS = [('arrow.api', 'get'), ('arrow.api', 'utcnow'), ('arrow.api', 'now'), ('arrow.api', 'factory'), ('arrow.arrow', 'Arrow'), ('arrow.factory', 'ArrowFactory'), ('arrow.formatter', 'DateTimeFormatter'), ('arrow.locales', 'Locale'), ('arrow.locales', 'EnglishLocale'), ('arrow.locales', 'ItalianLocale'), ('arrow.locales', 'SpanishLocale'), ('arrow.locales', 'FrenchBaseLocale'), ('arrow.locales', 'FrenchLocale'), ('arrow.locales', 'FrenchCanadianLocale'), ('arrow.locales', 'GreekLocale'), ('arrow.locales', 'JapaneseLocale'), ('arrow.locales', 'SwedishLocale'), ('arrow.locales', 'FinnishLocale')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_arrow_parses_shifts_and_formats_time():
    import arrow

    value = arrow.get("2025-01-02T03:04:05+00:00")
    assert value.shift(days=1).format("YYYY-MM-DD") == "2025-01-03"
    assert value.to("UTC").hour == 3
