"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_signal_dispatch_returns_receiver_results():
    from blinker import Signal

    signal = Signal()

    @signal.connect
    def receiver(sender, **kwargs):
        return sender + kwargs["delta"]

    results = signal.send(3, delta=4)
    assert results == [(receiver, 7)]
