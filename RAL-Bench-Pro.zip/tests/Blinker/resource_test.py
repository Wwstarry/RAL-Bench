"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_signal_dispatch_returns_receiver_results():
    from blinker import Signal

    signal = Signal()

    @signal.connect
    def receiver(sender, **kwargs):
        return sender + kwargs["delta"]

    results = signal.send(3, delta=4)
    assert results == [(receiver, 7)]
