from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mistletoe'
CORE_MODULES = ['mistletoe', 'mistletoe.contrib', 'mistletoe.__main__', 'mistletoe.ast_renderer', 'mistletoe.base_renderer', 'mistletoe.block_token']
PUBLIC_SYMBOLS = [('mistletoe', 'markdown'), ('mistletoe.__main__', 'main'), ('mistletoe.ast_renderer', 'AstRenderer'), ('mistletoe.ast_renderer', 'get_ast'), ('mistletoe.base_renderer', 'BaseRenderer'), ('mistletoe.block_token', 'BlockToken'), ('mistletoe.block_token', 'Document'), ('mistletoe.block_token', 'Heading'), ('mistletoe.block_token', 'SetextHeading'), ('mistletoe.block_token', 'Quote'), ('mistletoe.block_token', 'Paragraph'), ('mistletoe.block_token', 'BlockCode'), ('mistletoe.block_token', 'CodeFence'), ('mistletoe.block_token', 'List'), ('mistletoe.block_token', 'ListItem'), ('mistletoe.block_token', 'Table'), ('mistletoe.block_token', 'TableRow'), ('mistletoe.block_token', 'TableCell')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mistletoe_renders_lists_and_inline_code():
    import mistletoe

    rendered = mistletoe.markdown("- one\n- `two`\n")
    assert "<ul>" in rendered
    assert "<code>two</code>" in rendered
