"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mistletoe_renders_lists_and_inline_code():
    import mistletoe

    rendered = mistletoe.markdown("- one\n- `two`\n")
    assert "<ul>" in rendered
    assert "<code>two</code>" in rendered
