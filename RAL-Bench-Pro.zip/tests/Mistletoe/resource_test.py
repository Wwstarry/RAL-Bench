"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mistletoe_renders_lists_and_inline_code():
    import mistletoe

    rendered = mistletoe.markdown("- one\n- `two`\n")
    assert "<ul>" in rendered
    assert "<code>two</code>" in rendered
