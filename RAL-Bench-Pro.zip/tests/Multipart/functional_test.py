from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'multipart'
CORE_MODULES = ['multipart']
PUBLIC_SYMBOLS = [('multipart', 'MultipartError'), ('multipart', 'ParserError'), ('multipart', 'StrictParserError'), ('multipart', 'ParserLimitReached'), ('multipart', 'ParserStateError'), ('multipart', 'MultiDict'), ('multipart', 'PushMultipartParser'), ('multipart', 'MultipartSegment'), ('multipart', 'MultipartParser'), ('multipart', 'MultipartPart'), ('multipart', 'to_bytes'), ('multipart', 'copy_file'), ('multipart', 'header_quote'), ('multipart', 'header_unquote'), ('multipart', 'content_disposition_quote'), ('multipart', 'content_disposition_unquote'), ('multipart', 'parse_options_header'), ('multipart', 'is_form_request')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_multidict_preserves_repeated_form_values():
    from multipart import MultiDict

    values = MultiDict()
    values.append("tag", "one")
    values.append("tag", "two")
    assert values.get("tag") == "two"
    assert values.getall("tag") == ["one", "two"]
