"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_multidict_preserves_repeated_form_values():
    from multipart import MultiDict

    values = MultiDict()
    values.append("tag", "one")
    values.append("tag", "two")
    assert values.get("tag") == "two"
    assert values.getall("tag") == ["one", "two"]
