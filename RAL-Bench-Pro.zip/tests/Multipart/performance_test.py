"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_multidict_preserves_repeated_form_values():
    from multipart import MultiDict

    values = MultiDict()
    values.append("tag", "one")
    values.append("tag", "two")
    assert values.get("tag") == "two"
    assert values.getall("tag") == ["one", "two"]
