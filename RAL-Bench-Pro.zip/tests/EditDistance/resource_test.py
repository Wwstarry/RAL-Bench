"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_edit_distance_counts_insertions_deletions_and_substitutions():
    from edit_distance import edit_distance

    assert edit_distance("kitten", "sitting")[0] == 3
    assert edit_distance([], [1, 2])[0] == 2
