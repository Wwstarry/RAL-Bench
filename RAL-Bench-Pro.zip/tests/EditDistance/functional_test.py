from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'edit_distance'
CORE_MODULES = ['edit_distance', 'edit_distance.edit_distance']
PUBLIC_SYMBOLS = [('edit_distance.edit_distance', 'SequenceMatcher'), ('edit_distance.edit_distance', 'lowest_cost_action'), ('edit_distance.edit_distance', 'highest_match_action'), ('edit_distance.edit_distance', 'edit_distance'), ('edit_distance.edit_distance', 'edit_distance_backpointer'), ('edit_distance.edit_distance', 'get_opcodes_from_bp_table'), ('edit_distance.edit_distance', 'main')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_edit_distance_counts_insertions_deletions_and_substitutions():
    from edit_distance import edit_distance

    assert edit_distance("kitten", "sitting")[0] == 3
    assert edit_distance([], [1, 2])[0] == 2
