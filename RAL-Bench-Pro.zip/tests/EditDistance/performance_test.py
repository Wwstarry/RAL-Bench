"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_edit_distance_counts_insertions_deletions_and_substitutions():
    from edit_distance import edit_distance

    assert edit_distance("kitten", "sitting")[0] == 3
    assert edit_distance([], [1, 2])[0] == 2
