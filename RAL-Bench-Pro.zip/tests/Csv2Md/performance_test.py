"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_csv2md_table_renders_markdown_rows_and_headers():
    from csv2md.table import Table

    table = Table([["name", "score"], ["Ada", "10"]])
    rendered = table.markdown()
    assert "name" in rendered and "score" in rendered
    assert "Ada" in rendered and "10" in rendered
