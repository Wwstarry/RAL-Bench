from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'csv2md'
CORE_MODULES = ['csv2md', 'csv2md.__main__', 'csv2md.exceptions', 'csv2md.table', 'csv2md.utils']
PUBLIC_SYMBOLS = [('csv2md.__main__', 'main'), ('csv2md.__main__', 'parse_columns'), ('csv2md.__main__', 'process_file'), ('csv2md.exceptions', 'BaseError'), ('csv2md.exceptions', 'ColumnIdentifierError'), ('csv2md.table', 'Table'), ('csv2md.utils', 'column_letter')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_csv2md_table_renders_markdown_rows_and_headers():
    from csv2md.table import Table

    table = Table([["name", "score"], ["Ada", "10"]])
    rendered = table.markdown()
    assert "name" in rendered and "score" in rendered
    assert "Ada" in rendered and "10" in rendered
