"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_openapi_schema_validation_accepts_and_rejects_types():
    from jsonschema import ValidationError
    from openapi_schema_validator import validate

    schema = {"type": "integer", "minimum": 1}
    assert validate(3, schema) is None
    with pytest.raises(ValidationError):
        validate("3", schema)
