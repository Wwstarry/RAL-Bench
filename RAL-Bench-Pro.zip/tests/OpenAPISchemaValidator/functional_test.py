from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'openapi_schema_validator'
CORE_MODULES = ['openapi_schema_validator', 'openapi_schema_validator._caches', 'openapi_schema_validator._dialects', 'openapi_schema_validator._format', 'openapi_schema_validator._keywords', 'openapi_schema_validator._regex']
PUBLIC_SYMBOLS = [('openapi_schema_validator._caches', 'CachedValidator'), ('openapi_schema_validator._caches', 'ValidatorCache'), ('openapi_schema_validator._dialects', 'register_openapi_dialect'), ('openapi_schema_validator._format', 'is_int32'), ('openapi_schema_validator._format', 'is_int64'), ('openapi_schema_validator._format', 'is_float'), ('openapi_schema_validator._format', 'is_double'), ('openapi_schema_validator._format', 'is_binary_strict'), ('openapi_schema_validator._format', 'is_binary_pragmatic'), ('openapi_schema_validator._format', 'is_byte'), ('openapi_schema_validator._format', 'is_password'), ('openapi_schema_validator._format', 'is_regex'), ('openapi_schema_validator._keywords', 'handle_discriminator'), ('openapi_schema_validator._keywords', 'anyOf'), ('openapi_schema_validator._keywords', 'oneOf'), ('openapi_schema_validator._keywords', 'allOf'), ('openapi_schema_validator._keywords', 'type'), ('openapi_schema_validator._keywords', 'strict_type')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_openapi_schema_validation_accepts_and_rejects_types():
    from jsonschema import ValidationError
    from openapi_schema_validator import validate

    schema = {"type": "integer", "minimum": 1}
    assert validate(3, schema) is None
    with pytest.raises(ValidationError):
        validate("3", schema)
