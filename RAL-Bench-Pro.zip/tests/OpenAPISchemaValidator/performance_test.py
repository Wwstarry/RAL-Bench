"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_openapi_schema_validation_accepts_and_rejects_types():
    from jsonschema import ValidationError
    from openapi_schema_validator import validate

    schema = {"type": "integer", "minimum": 1}
    assert validate(3, schema) is None
    with pytest.raises(ValidationError):
        validate("3", schema)
