from __future__ import annotations

import os
import sys
from pathlib import Path


PROJECT_ID = 'OpenAPISchemaValidator'
PACKAGE_NAME = 'openapi_schema_validator'
IMPORT_ROOTS = ['.']


def _activate_repository() -> Path:
    value = os.environ.get("RACB_REPO_ROOT")
    if value:
        repo = Path(value).resolve()
    else:
        bench = Path(__file__).resolve().parents[2]
        target = os.environ.get(f"{PROJECT_ID.upper()}_TARGET", "generated")
        base = "repositories" if target == "reference" else "generation"
        repo = (bench / base / PROJECT_ID).resolve()
    for relative in reversed(IMPORT_ROOTS):
        import_root = repo if relative == "." else repo / relative
        sys.path.insert(0, str(import_root))
    return repo


REPO_ROOT = _activate_repository()


if PROJECT_ID == "Black":
    import types
    _black_version = types.ModuleType("_black_version")
    _black_version.version = "0+ralbench"
    sys.modules.setdefault("_black_version", _black_version)

if PROJECT_ID == "PytestFlask":
    import types
    _pytest_flask_version = types.ModuleType("pytest_flask._version")
    _pytest_flask_version.version = "0+ralbench"
    _pytest_flask_version.version_tuple = (0, 0)
    sys.modules.setdefault("pytest_flask._version", _pytest_flask_version)


# Source checkouts commonly obtain __version__ from installed distribution
# metadata.  Evaluation intentionally imports the checkout directly, so supply
# a neutral local version only for the project itself when no wheel metadata is
# present.  Dependency metadata is never masked.
import importlib.metadata as _metadata

_original_version = _metadata.version


def _checkout_version(name: str) -> str:
    normalized = name.lower().replace("-", "_")
    own_names = {PACKAGE_NAME.lower().replace("-", "_"), PROJECT_ID.lower().replace("-", "_")}
    if normalized in own_names:
        try:
            return _original_version(name)
        except _metadata.PackageNotFoundError:
            return "0+ralbench"
    return _original_version(name)


_metadata.version = _checkout_version
