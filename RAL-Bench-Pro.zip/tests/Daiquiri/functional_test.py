from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'daiquiri'
CORE_MODULES = ['daiquiri', 'daiquiri.formatter', 'daiquiri.handlers', 'daiquiri.output', 'daiquiri.types']
PUBLIC_SYMBOLS = [('daiquiri', 'KeywordArgumentAdapter'), ('daiquiri', 'getLogger'), ('daiquiri', 'setup'), ('daiquiri', 'parse_and_set_default_log_levels'), ('daiquiri', 'set_default_log_levels'), ('daiquiri.formatter', 'ColorFormatter'), ('daiquiri.formatter', 'ExtrasFormatter'), ('daiquiri.formatter', 'ColorExtrasFormatter'), ('daiquiri.formatter', 'DatadogFormatter'), ('daiquiri.handlers', 'SyslogHandler'), ('daiquiri.handlers', 'JournalHandler'), ('daiquiri.handlers', 'TTYDetectorStreamHandler'), ('daiquiri.handlers', 'PlainTextSocketHandler'), ('daiquiri.handlers', 'PlainTextDatagramHandler'), ('daiquiri.output', 'Output'), ('daiquiri.output', 'File'), ('daiquiri.output', 'RotatingFile'), ('daiquiri.output', 'TimedRotatingFile')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_daiquiri_extras_formatter_includes_record_extras():
    import logging
    from daiquiri.formatter import ExtrasFormatter

    record = logging.LogRecord("demo", logging.INFO, __file__, 1, "hello", (), None)
    record.request_id = "abc"
    record._daiquiri_extra_keys = {"request_id"}
    rendered = ExtrasFormatter(fmt="%(message)s%(extras)s").format(record)
    assert "hello" in rendered and "request_id" in rendered and "abc" in rendered
