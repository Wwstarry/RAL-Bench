"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_daiquiri_extras_formatter_includes_record_extras():
    import logging
    from daiquiri.formatter import ExtrasFormatter

    record = logging.LogRecord("demo", logging.INFO, __file__, 1, "hello", (), None)
    record.request_id = "abc"
    record._daiquiri_extra_keys = {"request_id"}
    rendered = ExtrasFormatter(fmt="%(message)s%(extras)s").format(record)
    assert "hello" in rendered and "request_id" in rendered and "abc" in rendered
