"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_spinner_cycles_through_configured_characters():
    from io import StringIO
    from click_spinner import Spinner

    output = StringIO()
    spinner = Spinner(stream=output, force=True)
    spinner.start()
    spinner.stop()
    assert any(char in output.getvalue() for char in "-/|\\")
