"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_spinner_cycles_through_configured_characters():
    from io import StringIO
    from click_spinner import Spinner

    output = StringIO()
    spinner = Spinner(stream=output, force=True)
    spinner.start()
    spinner.stop()
    assert any(char in output.getvalue() for char in "-/|\\")
