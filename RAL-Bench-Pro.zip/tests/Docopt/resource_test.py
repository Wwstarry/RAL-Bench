"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_docopt_parses_options_and_positionals():
    from docopt import docopt

    usage = "Usage: demo [--upper] <name>"
    parsed = docopt(usage, argv=["--upper", "alice"])
    assert parsed["--upper"] is True
    assert parsed["<name>"] == "alice"
