from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'docopt'
CORE_MODULES = ['docopt']
PUBLIC_SYMBOLS = [('docopt', 'DocoptLanguageError'), ('docopt', 'DocoptExit'), ('docopt', 'Pattern'), ('docopt', 'LeafPattern'), ('docopt', 'BranchPattern'), ('docopt', 'Argument'), ('docopt', 'Command'), ('docopt', 'Option'), ('docopt', 'Required'), ('docopt', 'Optional'), ('docopt', 'OptionsShortcut'), ('docopt', 'OneOrMore'), ('docopt', 'Either'), ('docopt', 'Tokens'), ('docopt', 'Dict'), ('docopt', 'transform'), ('docopt', 'parse_long'), ('docopt', 'parse_shorts')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_docopt_parses_options_and_positionals():
    from docopt import docopt

    usage = "Usage: demo [--upper] <name>"
    parsed = docopt(usage, argv=["--upper", "alice"])
    assert parsed["--upper"] is True
    assert parsed["<name>"] == "alice"
