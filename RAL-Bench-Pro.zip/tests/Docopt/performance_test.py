"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_docopt_parses_options_and_positionals():
    from docopt import docopt

    usage = "Usage: demo [--upper] <name>"
    parsed = docopt(usage, argv=["--upper", "alice"])
    assert parsed["--upper"] is True
    assert parsed["<name>"] == "alice"
