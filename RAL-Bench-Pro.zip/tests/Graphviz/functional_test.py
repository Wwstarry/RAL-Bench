from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'graphviz'
CORE_MODULES = ['graphviz', 'graphviz.backend', 'graphviz.parameters', 'graphviz._compat', 'graphviz._defaults', 'graphviz._tools']
PUBLIC_SYMBOLS = [('graphviz._compat', 'get_startupinfo'), ('graphviz._defaults', 'set_default_engine'), ('graphviz._defaults', 'set_default_format'), ('graphviz._defaults', 'set_jupyter_format'), ('graphviz._tools', 'attach'), ('graphviz._tools', 'mkdirs'), ('graphviz._tools', 'mapping_items'), ('graphviz._tools', 'promote_pathlike'), ('graphviz._tools', 'promote_pathlike_directory'), ('graphviz._tools', 'deprecate_positional_args')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_graph_source_contains_nodes_and_edges():
    from graphviz import Digraph

    graph = Digraph("demo")
    graph.node("A", "Start")
    graph.node("B", "End")
    graph.edge("A", "B")
    assert 'A [label=Start]' in graph.source
    assert "A -> B" in graph.source
