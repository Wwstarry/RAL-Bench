"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_graph_source_contains_nodes_and_edges():
    from graphviz import Digraph

    graph = Digraph("demo")
    graph.node("A", "Start")
    graph.node("B", "End")
    graph.edge("A", "B")
    assert 'A [label=Start]' in graph.source
    assert "A -> B" in graph.source
