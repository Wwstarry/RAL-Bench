"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_graph_source_contains_nodes_and_edges():
    from graphviz import Digraph

    graph = Digraph("demo")
    graph.node("A", "Start")
    graph.node("B", "End")
    graph.edge("A", "B")
    assert 'A [label=Start]' in graph.source
    assert "A -> B" in graph.source
