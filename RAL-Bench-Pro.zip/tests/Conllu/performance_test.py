"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_conllu_parses_and_serializes_dependency_sentences():
    from conllu import parse

    sentence = parse("1\tHello\thello\tINTJ\t_\t_\t0\troot\t_\t_\n")[0]
    assert sentence[0]["form"] == "Hello"
    assert sentence[0]["head"] == 0
    assert "\troot\t" in sentence.serialize()
