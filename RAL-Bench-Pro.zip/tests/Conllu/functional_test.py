from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'conllu'
CORE_MODULES = ['conllu', 'conllu.exceptions', 'conllu.models', 'conllu.parser', 'conllu.serializer']
PUBLIC_SYMBOLS = [('conllu', 'parse'), ('conllu', 'parse_incr'), ('conllu', 'parse_tree'), ('conllu', 'parse_tree_incr'), ('conllu.exceptions', 'ParseException'), ('conllu.models', 'Metadata'), ('conllu.models', 'Token'), ('conllu.models', 'TokenList'), ('conllu.models', 'TokenTree'), ('conllu.models', 'SentenceList'), ('conllu.models', 'SentenceGenerator'), ('conllu.models', 'traverse_dict'), ('conllu.parser', 'parse_sentences'), ('conllu.parser', 'parse_token_and_metadata'), ('conllu.parser', 'parse_line'), ('conllu.parser', 'parse_comment_line'), ('conllu.parser', 'parse_pair_value'), ('conllu.parser', 'parse_int_value')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_conllu_parses_and_serializes_dependency_sentences():
    from conllu import parse

    sentence = parse("1\tHello\thello\tINTJ\t_\t_\t0\troot\t_\t_\n")[0]
    assert sentence[0]["form"] == "Hello"
    assert sentence[0]["head"] == 0
    assert "\troot\t" in sentence.serialize()
