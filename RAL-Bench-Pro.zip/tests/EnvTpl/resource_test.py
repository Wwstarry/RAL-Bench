"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_envtpl_converts_json_values_for_template_contexts():
    from envtpl import from_json

    assert from_json('{"enabled": true, "count": 3}') == {"enabled": True, "count": 3}
    with pytest.raises(ValueError):
        from_json("plain text")
