"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_envtpl_converts_json_values_for_template_contexts():
    from envtpl import from_json

    assert from_json('{"enabled": true, "count": 3}') == {"enabled": True, "count": 3}
    with pytest.raises(ValueError):
        from_json("plain text")
