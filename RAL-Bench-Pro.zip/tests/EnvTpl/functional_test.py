from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'envtpl'
CORE_MODULES = ['envtpl']
PUBLIC_SYMBOLS = [('envtpl', 'Fatal'), ('envtpl', 'main'), ('envtpl', 'process_file'), ('envtpl', 'stdin_read'), ('envtpl', 'stdout_write'), ('envtpl', 'get_environment'), ('envtpl', 'from_json')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_envtpl_converts_json_values_for_template_contexts():
    from envtpl import from_json

    assert from_json('{"enabled": true, "count": 3}') == {"enabled": True, "count": 3}
    with pytest.raises(ValueError):
        from_json("plain text")
