"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_justhtml_sanitizes_scripts_and_serializes_safe_markup():
    from justhtml import JustHTML

    document = JustHTML('<p>Hello <strong>world</strong></p><script>alert(1)</script>')
    rendered = document.to_html(pretty=False)
    assert "<strong>world</strong>" in rendered
    assert "<script" not in rendered
