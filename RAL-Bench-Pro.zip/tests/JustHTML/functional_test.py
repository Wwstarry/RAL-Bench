from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'justhtml'
CORE_MODULES = ['justhtml', 'justhtml.core', 'justhtml.dom', 'justhtml.parser', 'justhtml.sanitizer', 'justhtml.selector']
PUBLIC_SYMBOLS = [('justhtml.dom', 'Node'), ('justhtml.dom', 'Document'), ('justhtml.dom', 'DocumentFragment'), ('justhtml.dom', 'Comment'), ('justhtml.dom', 'ProcessingInstruction'), ('justhtml.dom', 'Element'), ('justhtml.dom', 'Template'), ('justhtml.dom', 'Text'), ('justhtml.parser', 'StrictModeError'), ('justhtml.parser', 'JustHTML'), ('justhtml.transforms', 'Stage'), ('justhtml.transforms', 'emit_error'), ('justhtml.transforms', 'compile_transforms'), ('justhtml.transforms', 'apply_compiled_transforms'), ('justhtml.__main__', 'main'), ('justhtml.core.doctype', 'contains_prefix'), ('justhtml.core.doctype', 'doctype_error_and_quirks'), ('justhtml.core.entities', 'decode_numeric_entity')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_justhtml_sanitizes_scripts_and_serializes_safe_markup():
    from justhtml import JustHTML

    document = JustHTML('<p>Hello <strong>world</strong></p><script>alert(1)</script>')
    rendered = document.to_html(pretty=False)
    assert "<strong>world</strong>" in rendered
    assert "<script" not in rendered
