"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_justhtml_sanitizes_scripts_and_serializes_safe_markup():
    from justhtml import JustHTML

    document = JustHTML('<p>Hello <strong>world</strong></p><script>alert(1)</script>')
    rendered = document.to_html(pretty=False)
    assert "<strong>world</strong>" in rendered
    assert "<script" not in rendered
