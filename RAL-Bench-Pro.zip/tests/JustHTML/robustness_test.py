from __future__ import annotations

import importlib

import pytest


PACKAGE = 'justhtml'


def test_missing_public_attribute_raises_attribute_error():
    module = importlib.import_module(PACKAGE)
    with pytest.raises(AttributeError):
        getattr(module, "__ral_bench_missing_public_name__")


def test_missing_submodule_raises_module_not_found():
    with pytest.raises(ModuleNotFoundError):
        importlib.import_module(PACKAGE + ".__ral_bench_missing_submodule__")


def test_repeated_import_is_stable():
    first = importlib.import_module(PACKAGE)
    second = importlib.import_module(PACKAGE)
    assert first is second


def test_public_namespace_can_be_enumerated():
    module = importlib.import_module(PACKAGE)
    names = [name for name in dir(module) if not name.startswith("_")]
    assert isinstance(names, list)
