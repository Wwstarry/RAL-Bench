"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_ssh_config_resolves_host_aliases():
    from io import StringIO
    from paramiko.config import SSHConfig

    config = SSHConfig()
    config.parse(StringIO("Host demo\n  HostName example.test\n  Port 2222\n  User alice\n"))
    result = config.lookup("demo")
    assert result["hostname"] == "example.test"
    assert result["port"] == "2222"
    assert result["user"] == "alice"
