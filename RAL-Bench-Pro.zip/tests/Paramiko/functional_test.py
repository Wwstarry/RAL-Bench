from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'paramiko'
CORE_MODULES = ['paramiko', 'paramiko._winapi', 'paramiko.agent', 'paramiko.auth_handler', 'paramiko.auth_strategy', 'paramiko.ber']
PUBLIC_SYMBOLS = [('paramiko._winapi', 'WindowsError'), ('paramiko._winapi', 'MemoryMap'), ('paramiko._winapi', 'TokenAccess'), ('paramiko._winapi', 'TokenInformationClass'), ('paramiko._winapi', 'TOKEN_USER'), ('paramiko._winapi', 'SECURITY_DESCRIPTOR'), ('paramiko._winapi', 'SECURITY_ATTRIBUTES'), ('paramiko._winapi', 'format_system_message'), ('paramiko._winapi', 'handle_nonzero_success'), ('paramiko._winapi', 'GetTokenInformation'), ('paramiko._winapi', 'OpenProcessToken'), ('paramiko._winapi', 'get_current_user'), ('paramiko._winapi', 'get_security_attributes_for_user'), ('paramiko.agent', 'AgentSSH'), ('paramiko.agent', 'AgentProxyThread'), ('paramiko.agent', 'AgentLocalProxy'), ('paramiko.agent', 'AgentRemoteProxy'), ('paramiko.agent', 'AgentClientProxy')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_ssh_config_resolves_host_aliases():
    from io import StringIO
    from paramiko.config import SSHConfig

    config = SSHConfig()
    config.parse(StringIO("Host demo\n  HostName example.test\n  Port 2222\n  User alice\n"))
    result = config.lookup("demo")
    assert result["hostname"] == "example.test"
    assert result["port"] == "2222"
    assert result["user"] == "alice"
