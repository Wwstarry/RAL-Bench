"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_speller_corrects_common_english_typo():
    from autocorrect import Speller

    spell = Speller(lang="en")
    assert spell("speling") == "spelling"
