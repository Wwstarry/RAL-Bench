"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_speller_corrects_common_english_typo():
    from autocorrect import Speller

    spell = Speller(lang="en")
    assert spell("speling") == "spelling"
