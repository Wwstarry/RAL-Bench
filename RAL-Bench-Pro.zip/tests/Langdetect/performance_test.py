"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_language_detection_identifies_clear_english():
    from langdetect import DetectorFactory, detect

    DetectorFactory.seed = 0
    assert detect("This is a simple English sentence with several common words.") == "en"
