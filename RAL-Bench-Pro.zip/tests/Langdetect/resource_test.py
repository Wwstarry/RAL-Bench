"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_language_detection_identifies_clear_english():
    from langdetect import DetectorFactory, detect

    DetectorFactory.seed = 0
    assert detect("This is a simple English sentence with several common words.") == "en"
