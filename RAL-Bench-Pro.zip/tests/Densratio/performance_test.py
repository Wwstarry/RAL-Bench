"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_density_ratio_model_produces_positive_finite_estimates():
    import numpy as np
    from densratio import densratio

    np.random.seed(0)
    result = densratio(np.array([0.0, 0.1, 0.2]), np.array([1.0, 1.1, 1.2]), alpha=0.1, verbose=False)
    estimates = result.compute_density_ratio(np.array([0.0, 1.0]))
    assert estimates.shape == (2,)
    assert np.all(np.isfinite(estimates)) and np.all(estimates >= 0)
