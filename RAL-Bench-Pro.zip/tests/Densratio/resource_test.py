"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_density_ratio_model_produces_positive_finite_estimates():
    import numpy as np
    from densratio import densratio

    np.random.seed(0)
    result = densratio(np.array([0.0, 0.1, 0.2]), np.array([1.0, 1.1, 1.2]), alpha=0.1, verbose=False)
    estimates = result.compute_density_ratio(np.array([0.0, 1.0]))
    assert estimates.shape == (2,)
    assert np.all(np.isfinite(estimates)) and np.all(estimates >= 0)
