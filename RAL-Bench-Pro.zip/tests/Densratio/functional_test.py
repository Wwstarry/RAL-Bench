from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'densratio'
CORE_MODULES = ['densratio', 'densratio.KLIEP', 'densratio.RuLSIF', 'densratio.core', 'densratio.density_ratio', 'densratio.helpers']
PUBLIC_SYMBOLS = [('densratio.KLIEP', 'KLIEP'), ('densratio.KLIEP', 'KLIEP_search_sigma'), ('densratio.KLIEP', 'KLIEP_search_sigma_list'), ('densratio.KLIEP', 'KLIEP_compute_score_cv'), ('densratio.KLIEP', 'KLIEP_optimize_alpha'), ('densratio.KLIEP', 'compute_next_alpha'), ('densratio.KLIEP', 'KLIEP_compute_score'), ('densratio.RuLSIF', 'RuLSIF'), ('densratio.RuLSIF', 'search_sigma_and_lambda'), ('densratio.RuLSIF', 'compute_kernel_Gaussian'), ('densratio.RuLSIF', 'set_compute_kernel_target'), ('densratio.core', 'densratio'), ('densratio.core', 'uLSIF'), ('densratio.core', 'RuLSIF'), ('densratio.core', 'KLIEP'), ('densratio.density_ratio', 'DensityRatio'), ('densratio.density_ratio', 'KernelInfo'), ('densratio.density_ratio', 'my_format')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_density_ratio_model_produces_positive_finite_estimates():
    import numpy as np
    from densratio import densratio

    np.random.seed(0)
    result = densratio(np.array([0.0, 0.1, 0.2]), np.array([1.0, 1.1, 1.2]), alpha=0.1, verbose=False)
    estimates = result.compute_density_ratio(np.array([0.0, 1.0]))
    assert estimates.shape == (2,)
    assert np.all(np.isfinite(estimates)) and np.all(estimates >= 0)
