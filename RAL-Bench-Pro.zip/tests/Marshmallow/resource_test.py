"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_schema_loads_and_dumps_typed_fields():
    from marshmallow import Schema, fields

    class UserSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    schema = UserSchema()
    assert schema.load({"name": "Ada", "age": "36"}) == {"name": "Ada", "age": 36}
    assert schema.dump({"name": "Ada", "age": 36})["age"] == 36
