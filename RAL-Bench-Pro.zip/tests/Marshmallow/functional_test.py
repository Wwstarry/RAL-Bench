from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'marshmallow'
CORE_MODULES = ['marshmallow', 'marshmallow.experimental', 'marshmallow.class_registry', 'marshmallow.decorators', 'marshmallow.error_store', 'marshmallow.exceptions']
PUBLIC_SYMBOLS = [('marshmallow.class_registry', 'register'), ('marshmallow.class_registry', 'get_class'), ('marshmallow.decorators', 'MarshmallowHook'), ('marshmallow.decorators', 'validates'), ('marshmallow.decorators', 'validates_schema'), ('marshmallow.decorators', 'pre_dump'), ('marshmallow.decorators', 'post_dump'), ('marshmallow.decorators', 'pre_load'), ('marshmallow.decorators', 'post_load'), ('marshmallow.decorators', 'set_hook'), ('marshmallow.error_store', 'ErrorStore'), ('marshmallow.error_store', 'copy_containers'), ('marshmallow.error_store', 'merge_errors'), ('marshmallow.exceptions', 'MarshmallowError'), ('marshmallow.exceptions', 'ValidationError'), ('marshmallow.exceptions', 'RegistryError'), ('marshmallow.exceptions', 'StringNotCollectionError')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_schema_loads_and_dumps_typed_fields():
    from marshmallow import Schema, fields

    class UserSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    schema = UserSchema()
    assert schema.load({"name": "Ada", "age": "36"}) == {"name": "Ada", "age": 36}
    assert schema.dump({"name": "Ada", "age": 36})["age"] == 36
