"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mercantile_converts_coordinates_tiles_and_quadkeys():
    import mercantile

    tile = mercantile.tile(0.0, 0.0, 2)
    assert tile == mercantile.Tile(x=2, y=2, z=2)
    assert mercantile.quadkey(tile) == "30"
    assert mercantile.quadkey_to_tile("30") == tile
