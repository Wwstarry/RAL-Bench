from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mercantile'
CORE_MODULES = ['mercantile']
PUBLIC_SYMBOLS = [('mercantile', 'Tile'), ('mercantile', 'MercantileError'), ('mercantile', 'InvalidLatitudeError'), ('mercantile', 'InvalidZoomError'), ('mercantile', 'ParentTileError'), ('mercantile', 'QuadKeyError'), ('mercantile', 'TileArgParsingError'), ('mercantile', 'TileError'), ('mercantile', 'ul'), ('mercantile', 'bounds'), ('mercantile', 'truncate_lnglat'), ('mercantile', 'xy'), ('mercantile', 'lnglat'), ('mercantile', 'neighbors'), ('mercantile', 'xy_bounds'), ('mercantile', 'tile'), ('mercantile', 'quadkey'), ('mercantile', 'quadkey_to_tile')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mercantile_converts_coordinates_tiles_and_quadkeys():
    import mercantile

    tile = mercantile.tile(0.0, 0.0, 2)
    assert tile == mercantile.Tile(x=2, y=2, z=2)
    assert mercantile.quadkey(tile) == "30"
    assert mercantile.quadkey_to_tile("30") == tile
