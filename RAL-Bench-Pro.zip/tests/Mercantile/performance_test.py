"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mercantile_converts_coordinates_tiles_and_quadkeys():
    import mercantile

    tile = mercantile.tile(0.0, 0.0, 2)
    assert tile == mercantile.Tile(x=2, y=2, z=2)
    assert mercantile.quadkey(tile) == "30"
    assert mercantile.quadkey_to_tile("30") == tile
