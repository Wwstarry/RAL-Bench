from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mechanicalsoup'
CORE_MODULES = ['mechanicalsoup', 'mechanicalsoup.browser', 'mechanicalsoup.form', 'mechanicalsoup.stateful_browser', 'mechanicalsoup.utils']
PUBLIC_SYMBOLS = [('mechanicalsoup.browser', 'Browser'), ('mechanicalsoup.form', 'InvalidFormMethod'), ('mechanicalsoup.form', 'Form'), ('mechanicalsoup.stateful_browser', 'StatefulBrowser'), ('mechanicalsoup.utils', 'LinkNotFoundError'), ('mechanicalsoup.utils', 'is_multipart_file_upload')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mechanicalsoup_form_updates_inputs_and_builds_payload():
    from bs4 import BeautifulSoup
    from mechanicalsoup import Form

    form = Form(BeautifulSoup('<form method="post"><input name="user" value="old"></form>', "html.parser").form)
    form.set_input({"user": "Ada"})
    assert form.form.find("input", {"name": "user"})["value"] == "Ada"
    assert form.form.attrs["method"] == "post"
