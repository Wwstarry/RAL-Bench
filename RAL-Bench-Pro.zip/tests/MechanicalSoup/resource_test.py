"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mechanicalsoup_form_updates_inputs_and_builds_payload():
    from bs4 import BeautifulSoup
    from mechanicalsoup import Form

    form = Form(BeautifulSoup('<form method="post"><input name="user" value="old"></form>', "html.parser").form)
    form.set_input({"user": "Ada"})
    assert form.form.find("input", {"name": "user"})["value"] == "Ada"
    assert form.form.attrs["method"] == "post"
