from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'openapi_python_client'
CORE_MODULES = ['openapi_python_client', 'openapi_python_client.parser', 'openapi_python_client.schema', 'openapi_python_client.parser.properties', 'openapi_python_client.schema.openapi_schema_pydantic', 'openapi_python_client.cli']
PUBLIC_SYMBOLS = [('openapi_python_client', 'Project'), ('openapi_python_client', 'generate'), ('openapi_python_client.parser.properties', 'property_from_data'), ('openapi_python_client.parser.properties', 'build_schemas'), ('openapi_python_client.parser.properties', 'build_parameters'), ('openapi_python_client.cli', 'cli'), ('openapi_python_client.cli', 'handle_errors'), ('openapi_python_client.cli', 'generate')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_openapi_config_file_loads_json_overrides(tmp_path):
    import json
    from openapi_python_client.config import ConfigFile

    path = tmp_path / "config.json"
    path.write_text(json.dumps({"package_name_override": "demo_client", "http_timeout": 12}), encoding="utf-8")
    config = ConfigFile.load_from_path(path)
    assert config.package_name_override == "demo_client"
    assert config.http_timeout == 12
