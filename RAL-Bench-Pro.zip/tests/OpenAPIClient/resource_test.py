"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_openapi_config_file_loads_json_overrides(tmp_path):
    import json
    from openapi_python_client.config import ConfigFile

    path = tmp_path / "config.json"
    path.write_text(json.dumps({"package_name_override": "demo_client", "http_timeout": 12}), encoding="utf-8")
    config = ConfigFile.load_from_path(path)
    assert config.package_name_override == "demo_client"
    assert config.http_timeout == 12
