"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_cpplint_comment_cleaning_and_extension_classification():
    import cpplint

    assert cpplint.CleanseComments('int value = 1;  // explanation') == 'int value = 1;'
    assert cpplint.IsHeaderExtension("hpp") is True
    assert "cpp" in cpplint.GetNonHeaderExtensions()
