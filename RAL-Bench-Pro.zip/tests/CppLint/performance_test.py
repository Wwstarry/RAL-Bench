"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_cpplint_comment_cleaning_and_extension_classification():
    import cpplint

    assert cpplint.CleanseComments('int value = 1;  // explanation') == 'int value = 1;'
    assert cpplint.IsHeaderExtension("hpp") is True
    assert "cpp" in cpplint.GetNonHeaderExtensions()
