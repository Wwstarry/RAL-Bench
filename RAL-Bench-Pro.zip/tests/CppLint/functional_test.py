from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cpplint'
CORE_MODULES = ['cpplint']
PUBLIC_SYMBOLS = [('cpplint', 'ErrorSuppressions'), ('cpplint', 'FileInfo'), ('cpplint', 'CleansedLines'), ('cpplint', 'NestingState'), ('cpplint', 'ProcessHppHeadersOption'), ('cpplint', 'ProcessIncludeOrderOption'), ('cpplint', 'ProcessThirdPartyHeadersOption'), ('cpplint', 'IsHeaderExtension'), ('cpplint', 'GetHeaderExtensions'), ('cpplint', 'GetAllExtensions'), ('cpplint', 'ProcessExtensionsOption'), ('cpplint', 'GetNonHeaderExtensions'), ('cpplint', 'ParseNolintSuppressions'), ('cpplint', 'ProcessGlobalSuppressions'), ('cpplint', 'ResetNolintSuppressions'), ('cpplint', 'IsErrorSuppressedByNolint'), ('cpplint', 'Error'), ('cpplint', 'IsCppString')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_cpplint_comment_cleaning_and_extension_classification():
    import cpplint

    assert cpplint.CleanseComments('int value = 1;  // explanation') == 'int value = 1;'
    assert cpplint.IsHeaderExtension("hpp") is True
    assert "cpp" in cpplint.GetNonHeaderExtensions()
