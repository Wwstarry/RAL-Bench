"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_gita_formats_prefixed_multiline_output():
    from gita.utils import format_output

    assert format_output("one\ntwo\n", "repo") == "repo: one\nrepo: two\n"
