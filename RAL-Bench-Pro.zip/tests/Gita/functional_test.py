from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'gita'
CORE_MODULES = ['gita', 'gita.__main__', 'gita.common', 'gita.info', 'gita.io', 'gita.utils']
PUBLIC_SYMBOLS = [('gita', 'get_version'), ('gita.__main__', 'f_add'), ('gita.__main__', 'f_rename'), ('gita.__main__', 'f_flags'), ('gita.__main__', 'f_color'), ('gita.__main__', 'f_info'), ('gita.__main__', 'f_clone'), ('gita.__main__', 'f_freeze'), ('gita.__main__', 'f_ll'), ('gita.__main__', 'f_ls'), ('gita.__main__', 'f_group'), ('gita.__main__', 'f_context'), ('gita.__main__', 'f_rm'), ('gita.__main__', 'f_git_cmd'), ('gita.__main__', 'f_shell'), ('gita.__main__', 'f_super'), ('gita.__main__', 'f_clear'), ('gita.__main__', 'main')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_gita_formats_prefixed_multiline_output():
    from gita.utils import format_output

    assert format_output("one\ntwo\n", "repo") == "repo: one\nrepo: two\n"
