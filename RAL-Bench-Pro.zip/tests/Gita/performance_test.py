"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_gita_formats_prefixed_multiline_output():
    from gita.utils import format_output

    assert format_output("one\ntwo\n", "repo") == "repo: one\nrepo: two\n"
