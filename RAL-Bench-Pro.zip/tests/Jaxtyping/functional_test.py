from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jaxtyping'
CORE_MODULES = ['jaxtyping', 'jaxtyping._typeguard', 'jaxtyping._array_types', 'jaxtyping._decorator', 'jaxtyping._errors', 'jaxtyping._import_hook']
PUBLIC_SYMBOLS = [('jaxtyping._typeguard', 'ForwardRefPolicy'), ('jaxtyping._typeguard', 'TypeHintWarning'), ('jaxtyping._typeguard', 'TypeCheckedGenerator'), ('jaxtyping._typeguard', 'TypeCheckedAsyncGenerator'), ('jaxtyping._typeguard', 'TypeWarning'), ('jaxtyping._typeguard', 'TypeChecker'), ('jaxtyping._typeguard', 'resolve_forwardref'), ('jaxtyping._typeguard', 'get_type_name'), ('jaxtyping._typeguard', 'find_function'), ('jaxtyping._typeguard', 'qualified_name'), ('jaxtyping._typeguard', 'function_name'), ('jaxtyping._typeguard', 'check_callable'), ('jaxtyping._typeguard', 'check_dict'), ('jaxtyping._typeguard', 'check_typed_dict'), ('jaxtyping._typeguard', 'check_list'), ('jaxtyping._typeguard', 'check_sequence'), ('jaxtyping._typeguard', 'check_set'), ('jaxtyping._typeguard', 'check_tuple')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_array_annotation_name_format_is_configurable():
    import jaxtyping

    original = jaxtyping.get_array_name_format()
    try:
        jaxtyping.set_array_name_format("array")
        assert jaxtyping.get_array_name_format() == "array"
    finally:
        jaxtyping.set_array_name_format(original)
