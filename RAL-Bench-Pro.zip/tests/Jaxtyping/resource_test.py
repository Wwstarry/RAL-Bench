"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_array_annotation_name_format_is_configurable():
    import jaxtyping

    original = jaxtyping.get_array_name_format()
    try:
        jaxtyping.set_array_name_format("array")
        assert jaxtyping.get_array_name_format() == "array"
    finally:
        jaxtyping.set_array_name_format(original)
