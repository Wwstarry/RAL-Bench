"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_array_annotation_name_format_is_configurable():
    import jaxtyping

    original = jaxtyping.get_array_name_format()
    try:
        jaxtyping.set_array_name_format("array")
        assert jaxtyping.get_array_name_format() == "array"
    finally:
        jaxtyping.set_array_name_format(original)
