"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_korean_romanizer_transliterates_hangul_syllables():
    from korean_romanizer.romanizer import Romanizer

    assert Romanizer("가").romanize() == "ga"
    assert Romanizer("한글").romanize().startswith("han")
