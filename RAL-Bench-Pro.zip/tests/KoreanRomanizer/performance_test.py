"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_korean_romanizer_transliterates_hangul_syllables():
    from korean_romanizer.romanizer import Romanizer

    assert Romanizer("가").romanize() == "ga"
    assert Romanizer("한글").romanize().startswith("han")
