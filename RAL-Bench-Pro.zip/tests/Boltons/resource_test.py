"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_chunked_groups_iterables_with_remainder():
    from boltons.iterutils import chunked

    assert chunked(range(5), 2) == [[0, 1], [2, 3], [4]]
