"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_chunked_groups_iterables_with_remainder():
    from boltons.iterutils import chunked

    assert chunked(range(5), 2) == [[0, 1], [2, 3], [4]]
