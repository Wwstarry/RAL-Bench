from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'boltons'
CORE_MODULES = ['boltons', 'boltons.cacheutils', 'boltons.debugutils', 'boltons.deprutils', 'boltons.dictutils', 'boltons.easterutils']
PUBLIC_SYMBOLS = [('boltons.cacheutils', 'LRI'), ('boltons.cacheutils', 'LRU'), ('boltons.cacheutils', 'CachedFunction'), ('boltons.cacheutils', 'CachedMethod'), ('boltons.cacheutils', 'cachedproperty'), ('boltons.cacheutils', 'ThresholdCounter'), ('boltons.cacheutils', 'MinIDMap'), ('boltons.cacheutils', 'make_cache_key'), ('boltons.cacheutils', 'cached'), ('boltons.cacheutils', 'cachedmethod'), ('boltons.debugutils', 'pdb_on_signal'), ('boltons.debugutils', 'pdb_on_exception'), ('boltons.debugutils', 'trace_print_hook'), ('boltons.debugutils', 'wrap_trace'), ('boltons.deprutils', 'DeprecatableModule'), ('boltons.deprutils', 'deprecate_module_member'), ('boltons.dictutils', 'OrderedMultiDict'), ('boltons.dictutils', 'FastIterOrderedMultiDict')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_chunked_groups_iterables_with_remainder():
    from boltons.iterutils import chunked

    assert chunked(range(5), 2) == [[0, 1], [2, 3], [4]]
