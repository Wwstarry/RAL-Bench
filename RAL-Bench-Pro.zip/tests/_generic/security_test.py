import ast
import os
import shutil
import subprocess
import sys
import tokenize
import warnings
from io import StringIO
from pathlib import Path
from typing import Iterable, List, Tuple, Dict, Any

REPO_ROOT_ENV = "RACB_REPO_ROOT"
PKG_NAME_ENV = "RACB_PACKAGE_NAME"
SYNTAX_PYTHON_VERSION_ENV = "RACB_SYNTAX_PYTHON_VERSION"
ALLOW_PY2_REFERENCE_ENV = "RACB_ALLOW_PY2_REFERENCE_SOURCE"

EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    "venv",
    ".venv",
    "env",
    "build",
    "dist",
    "site-packages",
    "tests",
}


def _repo_root() -> Path:
    v = os.environ.get(REPO_ROOT_ENV, "").strip()
    if not v:
        # Fallback to project root if not provided
        return Path(__file__).resolve().parents[2]
    return Path(v).resolve()


def _scan_root(repo_root: Path) -> Path:
    pkg = os.environ.get(PKG_NAME_ENV, "").strip()
    if pkg:
        cand = (repo_root / pkg).resolve()
        if cand.exists() and cand.is_dir():
            return cand
    return repo_root


def _iter_py_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*.py"):
        parts = set(p.parts)
        if any(x in parts for x in EXCLUDE_DIRS):
            continue
        # Skip huge generated caches if any
        if p.name.endswith(".pyi"):
            continue
        yield p


def _read_text(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8-sig", errors="ignore")
    except Exception:
        return ""


def _count_loc(text: str) -> int:
    loc = 0
    for ln in text.splitlines():
        s = ln.strip()
        if not s:
            continue
        if s.startswith("#"):
            continue
        loc += 1
    return loc


def _get_call_name(node: ast.AST) -> str:
    # Returns dotted call name like "os.system" or "subprocess.run"
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _get_call_name(node.value)
        if base:
            return f"{base}.{node.attr}"
        return node.attr
    return ""


def _kw_bool(kwargs: List[ast.keyword], name: str) -> bool:
    for kw in kwargs:
        if kw.arg == name:
            v = kw.value
            if isinstance(v, ast.Constant) and isinstance(v.value, bool):
                return bool(v.value)
            # handle NameConstant (py<3.8) not needed, but safe
    return False


class _SecurityVisitor(ast.NodeVisitor):
    """
    Count high-risk patterns:
      - eval(...)
      - exec(...)
      - os.system(...)
      - subprocess.* with shell=True (run/call/check_output/Popen/...)
      - pickle.loads / pickle.load / pickle.Unpickler / dill.loads/load (if present)
    """
    def __init__(self) -> None:
        self.high_risk_count = 0
        self.imports: Dict[str, str] = {}  # local_name -> module name

    def visit_Import(self, node: ast.Import) -> Any:
        for alias in node.names:
            name = alias.name  # e.g., "os", "subprocess", "pickle"
            asname = alias.asname or name.split(".")[-1]
            self.imports[asname] = name
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> Any:
        mod = node.module or ""
        for alias in node.names:
            asname = alias.asname or alias.name
            # map imported symbol to module.symbol (approx)
            self.imports[asname] = f"{mod}.{alias.name}" if mod else alias.name
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> Any:
        fn = _get_call_name(node.func)

        # Resolve simple aliases: if call is "system(...)" but imported as "from os import system"
        if fn in self.imports:
            fn = self.imports[fn]

        # eval / exec
        if fn in {"eval", "exec"}:
            self.high_risk_count += 1
            return self.generic_visit(node)

        # os.system
        if fn == "os.system":
            self.high_risk_count += 1
            return self.generic_visit(node)

        # subprocess.* with shell=True
        if fn.startswith("subprocess."):
            if _kw_bool(list(node.keywords or []), "shell"):
                self.high_risk_count += 1
                return self.generic_visit(node)

        # pickle / dill / cloudpickle loads/load
        if fn in {
            "pickle.loads",
            "pickle.load",
            "pickle.Unpickler",
            "dill.loads",
            "dill.load",
            "cloudpickle.loads",
            "cloudpickle.load",
        }:
            self.high_risk_count += 1
            return self.generic_visit(node)

        self.generic_visit(node)


def _syntax_command(version: str) -> List[str]:
    major_minor = version.strip()
    if os.name == "nt" and shutil.which("py"):
        return ["py", f"-{major_minor}"]
    executable = shutil.which(f"python{major_minor}")
    return [executable] if executable else []


def _external_syntax_is_valid(text: str, version: str) -> bool:
    command = _syntax_command(version)
    if not command:
        return False
    try:
        completed = subprocess.run(
            command + ["-c", "import ast,sys; ast.parse(sys.stdin.read())"],
            input=text,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return completed.returncode == 0


def _fallback_high_risk_count(text: str) -> int:
    """Token-level fallback for syntax newer than the scanner interpreter."""
    try:
        tokens = [
            token
            for token in tokenize.generate_tokens(StringIO(text).readline)
            if token.type
            not in {
                tokenize.ENCODING,
                tokenize.ENDMARKER,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.NEWLINE,
                tokenize.NL,
                tokenize.COMMENT,
                tokenize.STRING,
            }
        ]
    except (IndentationError, tokenize.TokenError):
        # Conservative fallback for indentation-damaged legacy token streams.
        patterns = [
            r"\b(?:eval|exec)\s*\(",
            r"\bos\s*\.\s*system\s*\(",
            r"\b(?:pickle|dill|cloudpickle)\s*\.\s*(?:loads?|Unpickler)\s*\(",
            r"\bsubprocess\s*\.[A-Za-z_]+\s*\([^\n]*\bshell\s*=\s*True",
        ]
        return sum(len(re.findall(pattern, text)) for pattern in patterns)

    high = 0
    for index, token in enumerate(tokens):
        value = token.string
        next_value = tokens[index + 1].string if index + 1 < len(tokens) else ""
        if value in {"eval", "exec"} and next_value == "(":
            high += 1
        if index + 3 < len(tokens):
            dotted = "".join(t.string for t in tokens[index : index + 3])
            after = tokens[index + 3].string
            if dotted == "os.system" and after == "(":
                high += 1
            if dotted in {
                "pickle.loads",
                "pickle.load",
                "pickle.Unpickler",
                "dill.loads",
                "dill.load",
                "cloudpickle.loads",
                "cloudpickle.load",
            } and after == "(":
                high += 1
            if dotted.startswith("subprocess.") and after == "(":
                depth = 0
                for offset, nested in enumerate(tokens[index + 3 :]):
                    if nested.string == "(":
                        depth += 1
                    elif nested.string == ")":
                        depth -= 1
                        if depth <= 0:
                            break
                    elif nested.string == "shell" and depth > 0:
                        # Find shell=True within this call without evaluating it.
                        pos = index + 3 + offset
                        tail = [t.string for t in tokens[pos : pos + 3]]
                        if tail == ["shell", "=", "True"]:
                            high += 1
                            break
    return high


def _python2_source_converts(text: str) -> bool:
    """Validate explicitly declared Python 2 grammar before fallback scanning.

    The converted text is deliberately not compiled as Python 3: identifiers
    such as ``async`` were legal in Python 2 and are not rewritten by lib2to3.
    """
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            from lib2to3.refactor import RefactoringTool, get_fixers_from_package

            tool = RefactoringTool(get_fixers_from_package("lib2to3.fixes"))
            tool.refactor_string(text + ("" if text.endswith("\n") else "\n"), "<source>")
    except Exception:
        return False
    return True


def _analyze_file(path: Path) -> Tuple[int, int, int, int]:
    """
    Return (high_risk_count, loc, syntax_error_count, fallback_parse_count)
    """
    text = _read_text(path)
    if not text.strip():
        return (0, 0, 0, 0)
    loc = _count_loc(text)
    try:
        tree = ast.parse(text)
    except SyntaxError:
        target_version = os.environ.get(SYNTAX_PYTHON_VERSION_ENV, "").strip()
        if target_version and _external_syntax_is_valid(text, target_version):
            return (_fallback_high_risk_count(text), loc, 0, 1)
        if os.environ.get(ALLOW_PY2_REFERENCE_ENV) == "1" and _python2_source_converts(text):
            return (_fallback_high_risk_count(text), loc, 0, 1)
        # Invalid source must not receive a perfect security score merely because
        # the AST scanner could not inspect it.
        return (0, loc, 1, 0)

    v = _SecurityVisitor()
    v.visit(tree)
    return (v.high_risk_count, loc, 0, 0)


def test_security_high_risk_count_metric() -> None:
    repo = _repo_root()
    root = _scan_root(repo)

    files = list(_iter_py_files(root))
    high = 0
    total_loc = 0
    syntax_errors = 0
    fallback_parsed = 0

    for f in files:
        h, loc, parse_errors, fallback_count = _analyze_file(f)
        high += h
        total_loc += loc
        syntax_errors += parse_errors
        fallback_parsed += fallback_count

    # Single comparable metric: high_risk_count (lower is better)
    print(
        f"SECURITY_METRICS high_risk_count={float(high)} "
        f"files_scanned={float(len(files))} total_loc={float(total_loc)} "
        f"syntax_errors={float(syntax_errors)} fallback_parsed={float(fallback_parsed)}"
    )

    assert files, f"No Python source files found under: {root}"
    assert syntax_errors == 0, f"{syntax_errors} Python files could not be parsed"
