from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mistune'
CORE_MODULES = ['mistune', 'mistune.directives', 'mistune.plugins', 'mistune.renderers', 'mistune.__main__', 'mistune.block_parser']
PUBLIC_SYMBOLS = [('mistune', 'create_markdown'), ('mistune', 'markdown'), ('mistune.directives', 'RstDirective'), ('mistune.plugins', 'Plugin'), ('mistune.plugins', 'import_plugin'), ('mistune.__main__', 'cli'), ('mistune.__main__', 'read_stdin'), ('mistune.block_parser', 'BlockParser'), ('mistune.core', 'BlockState'), ('mistune.core', 'InlineState'), ('mistune.core', 'Parser'), ('mistune.core', 'BaseRenderer'), ('mistune.helpers', 'unescape_char'), ('mistune.helpers', 'parse_link_text'), ('mistune.helpers', 'parse_link_label'), ('mistune.helpers', 'parse_link_href'), ('mistune.helpers', 'parse_link_title'), ('mistune.helpers', 'parse_link')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mistune_renders_markdown_links_and_strong_text():
    import mistune

    rendered = mistune.html("**bold** and [link](https://example.test)")
    assert "<strong>bold</strong>" in rendered
    assert 'href="https://example.test"' in rendered
