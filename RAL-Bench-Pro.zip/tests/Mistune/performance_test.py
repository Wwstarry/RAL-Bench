"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mistune_renders_markdown_links_and_strong_text():
    import mistune

    rendered = mistune.html("**bold** and [link](https://example.test)")
    assert "<strong>bold</strong>" in rendered
    assert 'href="https://example.test"' in rendered
