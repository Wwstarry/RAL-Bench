"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mistune_renders_markdown_links_and_strong_text():
    import mistune

    rendered = mistune.html("**bold** and [link](https://example.test)")
    assert "<strong>bold</strong>" in rendered
    assert 'href="https://example.test"' in rendered
