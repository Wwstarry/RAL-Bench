"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_marko_renders_markdown_headings_and_emphasis():
    import marko

    rendered = marko.convert("# Hello\n\nThis is *important*.")
    assert "<h1>Hello</h1>" in rendered
    assert "<em>important</em>" in rendered
