from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'marko'
CORE_MODULES = ['marko', 'marko.ext', 'marko.ext.gfm', 'marko.ast_renderer', 'marko.block', 'marko.cli']
PUBLIC_SYMBOLS = [('marko', 'SetupDone'), ('marko', 'Markdown'), ('marko', 'convert'), ('marko', 'parse'), ('marko', 'render'), ('marko.ext.gfm', 'make_extension'), ('marko.ast_renderer', 'ASTRenderer'), ('marko.ast_renderer', 'XMLRenderer'), ('marko.block', 'BlockElement'), ('marko.block', 'Document'), ('marko.block', 'BlankLine'), ('marko.block', 'Heading'), ('marko.block', 'SetextHeading'), ('marko.block', 'CodeBlock'), ('marko.block', 'FencedCode'), ('marko.block', 'ThematicBreak'), ('marko.block', 'HTMLBlock'), ('marko.block', 'Paragraph')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_marko_renders_markdown_headings_and_emphasis():
    import marko

    rendered = marko.convert("# Hello\n\nThis is *important*.")
    assert "<h1>Hello</h1>" in rendered
    assert "<em>important</em>" in rendered
