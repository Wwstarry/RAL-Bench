"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_marko_renders_markdown_headings_and_emphasis():
    import marko

    rendered = marko.convert("# Hello\n\nThis is *important*.")
    assert "<h1>Hello</h1>" in rendered
    assert "<em>important</em>" in rendered
