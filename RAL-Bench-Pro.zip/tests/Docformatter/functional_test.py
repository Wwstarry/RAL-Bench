from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'docformatter'
CORE_MODULES = ['docformatter', 'docformatter.patterns', 'docformatter.wrappers', 'docformatter.__main__', 'docformatter.classify', 'docformatter.configuration']
PUBLIC_SYMBOLS = [('docformatter.__main__', 'main'), ('docformatter.classify', 'do_find_docstring_blocks'), ('docformatter.classify', 'is_attribute_docstring'), ('docformatter.classify', 'is_class_docstring'), ('docformatter.classify', 'is_closing_quotes'), ('docformatter.classify', 'is_code_line'), ('docformatter.classify', 'is_definition_line'), ('docformatter.classify', 'is_f_string'), ('docformatter.classify', 'is_function_or_method_docstring'), ('docformatter.classify', 'is_inline_comment'), ('docformatter.classify', 'is_line_following_indent'), ('docformatter.classify', 'is_module_docstring'), ('docformatter.classify', 'is_nested_definition_line'), ('docformatter.classify', 'is_newline_continuation'), ('docformatter.classify', 'is_string_variable'), ('docformatter.classify', 'is_docstring_at_end_of_file'), ('docformatter.configuration', 'Configurater'), ('docformatter.encode', 'Encoder')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_docformatter_classifies_python_definition_tokens():
    import io
    import tokenize
    from docformatter.classify import is_code_line, is_definition_line

    tokens = list(tokenize.generate_tokens(io.StringIO("def example(value):\n    return value\n").readline))
    assert any(is_definition_line(token) for token in tokens)
    assert any(is_code_line(token) for token in tokens)
