"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_docformatter_classifies_python_definition_tokens():
    import io
    import tokenize
    from docformatter.classify import is_code_line, is_definition_line

    tokens = list(tokenize.generate_tokens(io.StringIO("def example(value):\n    return value\n").readline))
    assert any(is_definition_line(token) for token in tokens)
    assert any(is_code_line(token) for token in tokens)
