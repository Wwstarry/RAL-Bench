"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_flask_moment_generates_client_side_timestamp_markup():
    from datetime import datetime, timezone
    from flask import Flask
    from flask_moment import Moment, moment

    app = Flask(__name__)
    Moment(app)
    with app.app_context():
        markup = str(moment(datetime(2025, 1, 2, tzinfo=timezone.utc)).format("YYYY-MM-DD"))
    assert "2025-01-02" in markup
    assert 'data-function="format"' in markup
