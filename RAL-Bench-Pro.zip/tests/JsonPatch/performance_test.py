"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_json_patch_applies_add_replace_and_remove():
    import jsonpatch

    document = {"name": "old", "items": [1, 2]}
    patch = [
        {"op": "replace", "path": "/name", "value": "new"},
        {"op": "add", "path": "/items/-", "value": 3},
        {"op": "remove", "path": "/items/0"},
    ]
    assert jsonpatch.apply_patch(document, patch) == {"name": "new", "items": [2, 3]}
