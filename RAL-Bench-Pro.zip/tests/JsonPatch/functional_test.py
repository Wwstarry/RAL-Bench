from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jsonpatch'
CORE_MODULES = ['jsonpatch']
PUBLIC_SYMBOLS = [('jsonpatch', 'JsonPatchException'), ('jsonpatch', 'InvalidJsonPatch'), ('jsonpatch', 'JsonPatchConflict'), ('jsonpatch', 'JsonPatchTestFailed'), ('jsonpatch', 'PatchOperation'), ('jsonpatch', 'RemoveOperation'), ('jsonpatch', 'AddOperation'), ('jsonpatch', 'ReplaceOperation'), ('jsonpatch', 'MoveOperation'), ('jsonpatch', 'TestOperation'), ('jsonpatch', 'CopyOperation'), ('jsonpatch', 'JsonPatch'), ('jsonpatch', 'DiffBuilder'), ('jsonpatch', 'multidict'), ('jsonpatch', 'apply_patch'), ('jsonpatch', 'make_patch')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_json_patch_applies_add_replace_and_remove():
    import jsonpatch

    document = {"name": "old", "items": [1, 2]}
    patch = [
        {"op": "replace", "path": "/name", "value": "new"},
        {"op": "add", "path": "/items/-", "value": 3},
        {"op": "remove", "path": "/items/0"},
    ]
    assert jsonpatch.apply_patch(document, patch) == {"name": "new", "items": [2, 3]}
