"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_iterable_chunking_and_windowing():
    from more_itertools import chunked, windowed

    assert list(chunked(range(5), 2)) == [[0, 1], [2, 3], [4]]
    assert list(windowed([1, 2, 3], 2)) == [(1, 2), (2, 3)]
