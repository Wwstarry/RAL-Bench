"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_iterable_chunking_and_windowing():
    from more_itertools import chunked, windowed

    assert list(chunked(range(5), 2)) == [[0, 1], [2, 3], [4]]
    assert list(windowed([1, 2, 3], 2)) == [(1, 2), (2, 3)]
