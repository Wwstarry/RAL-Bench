from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'more_itertools'
CORE_MODULES = ['more_itertools', 'more_itertools.more', 'more_itertools.recipes']
PUBLIC_SYMBOLS = [('more_itertools.more', 'peekable'), ('more_itertools.more', 'sized_iterator'), ('more_itertools.more', 'bucket'), ('more_itertools.more', 'numeric_range'), ('more_itertools.more', 'islice_extended'), ('more_itertools.more', 'SequenceView'), ('more_itertools.more', 'seekable'), ('more_itertools.more', 'run_length'), ('more_itertools.more', 'time_limited'), ('more_itertools.more', 'AbortThread'), ('more_itertools.more', 'callback_iter'), ('more_itertools.more', 'countable'), ('more_itertools.more', 'serialize'), ('more_itertools.more', 'chunked'), ('more_itertools.more', 'first'), ('more_itertools.more', 'last'), ('more_itertools.more', 'nth_or_last'), ('more_itertools.more', 'consumer')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_iterable_chunking_and_windowing():
    from more_itertools import chunked, windowed

    assert list(chunked(range(5), 2)) == [[0, 1], [2, 3], [4]]
    assert list(windowed([1, 2, 3], 2)) == [(1, 2), (2, 3)]
