"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_hearthstone_deckstrings_round_trip_a_deck():
    from hearthstone.deckstrings import Deck
    from hearthstone.enums import FormatType

    deck = Deck()
    deck.heroes = [7]
    deck.cards = [(315, 2), (662, 1)]
    deck.format = FormatType.FT_STANDARD
    encoded = deck.as_deckstring
    decoded = Deck.from_deckstring(encoded)
    assert decoded.heroes == [7]
    assert sorted(decoded.cards) == [(315, 2), (662, 1)]
