from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'hearthstone'
CORE_MODULES = ['hearthstone', 'hearthstone.utils', 'hearthstone.bountyxml', 'hearthstone.cardxml', 'hearthstone.dbf', 'hearthstone.deckstrings']
PUBLIC_SYMBOLS = [('hearthstone.utils', 'get_original_card_id'), ('hearthstone.utils', 'get_copied_card_id_by_format'), ('hearthstone.bountyxml', 'BountyXML'), ('hearthstone.bountyxml', 'load'), ('hearthstone.cardxml', 'CardXML'), ('hearthstone.cardxml', 'prop'), ('hearthstone.cardxml', 'load'), ('hearthstone.cardxml', 'load_dbf'), ('hearthstone.dbf', 'Dbf'), ('hearthstone.deckstrings', 'Deck'), ('hearthstone.deckstrings', 'trisort_cards'), ('hearthstone.deckstrings', 'parse_deckstring'), ('hearthstone.deckstrings', 'write_deckstring'), ('hearthstone.entities', 'Entity'), ('hearthstone.entities', 'Game'), ('hearthstone.entities', 'Player'), ('hearthstone.entities', 'Card'), ('hearthstone.enums', 'GameTag')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_hearthstone_deckstrings_round_trip_a_deck():
    from hearthstone.deckstrings import Deck
    from hearthstone.enums import FormatType

    deck = Deck()
    deck.heroes = [7]
    deck.cards = [(315, 2), (662, 1)]
    deck.format = FormatType.FT_STANDARD
    encoded = deck.as_deckstring
    decoded = Deck.from_deckstring(encoded)
    assert decoded.heroes == [7]
    assert sorted(decoded.cards) == [(315, 2), (662, 1)]
