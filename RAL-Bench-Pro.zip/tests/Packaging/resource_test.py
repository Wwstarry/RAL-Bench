"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_packaging_versions_follow_pep440_ordering():
    from packaging.version import Version

    assert Version("1.0rc1") < Version("1.0") < Version("1.0.post1")
    assert str(Version("01.2.0")) == "1.2.0"
