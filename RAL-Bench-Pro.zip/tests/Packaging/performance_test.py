"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_packaging_versions_follow_pep440_ordering():
    from packaging.version import Version

    assert Version("1.0rc1") < Version("1.0") < Version("1.0.post1")
    assert str(Version("01.2.0")) == "1.2.0"
