from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'packaging'
CORE_MODULES = ['packaging', 'packaging.licenses', 'packaging._elffile', 'packaging._manylinux', 'packaging._musllinux', 'packaging._parser']
PUBLIC_SYMBOLS = [('packaging.licenses', 'InvalidLicenseExpression'), ('packaging.licenses', 'canonicalize_license_expression'), ('packaging._elffile', 'ELFInvalid'), ('packaging._elffile', 'EIClass'), ('packaging._elffile', 'EIData'), ('packaging._elffile', 'EMachine'), ('packaging._elffile', 'ELFFile'), ('packaging._manylinux', 'platform_tags'), ('packaging._musllinux', 'platform_tags'), ('packaging._parser', 'Node'), ('packaging._parser', 'Variable'), ('packaging._parser', 'Value'), ('packaging._parser', 'Op'), ('packaging._parser', 'ParsedRequirement'), ('packaging._parser', 'parse_requirement'), ('packaging._parser', 'parse_marker'), ('packaging._parser', 'process_env_var'), ('packaging._parser', 'process_python_str')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_packaging_versions_follow_pep440_ordering():
    from packaging.version import Version

    assert Version("1.0rc1") < Version("1.0") < Version("1.0.post1")
    assert str(Version("01.2.0")) == "1.2.0"
