"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_case_insensitive_multidict_preserves_multiple_values():
    from multidict import CIMultiDict

    headers = CIMultiDict()
    headers.add("X-Test", "one")
    headers.add("x-test", "two")
    assert headers["X-TEST"] == "one"
    assert headers.getall("x-test") == ["one", "two"]
