"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_case_insensitive_multidict_preserves_multiple_values():
    from multidict import CIMultiDict

    headers = CIMultiDict()
    headers.add("X-Test", "one")
    headers.add("x-test", "two")
    assert headers["X-TEST"] == "one"
    assert headers.getall("x-test") == ["one", "two"]
