"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mysql_sql_analysis_extracts_tables_and_destructive_queries():
    from mycli.packages.sql_utils import extract_tables, is_destructive

    tables = extract_tables("SELECT u.id FROM app.users AS u JOIN audit.logs l ON u.id = l.user_id")
    assert ("app", "users", "u") in tables
    assert ("audit", "logs", "l") in tables
    assert is_destructive(["drop", "delete"], "DROP TABLE users") is True
    assert is_destructive(["drop", "delete"], "SELECT * FROM users") is False
