from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mycli'
CORE_MODULES = ['mycli', 'mycli.packages', 'mycli.packages.ptoolkit', 'mycli.packages.special', 'mycli.packages.tabular_output', 'mycli.app_state']
PUBLIC_SYMBOLS = [('mycli.app_state', 'AppStateMixin'), ('mycli.app_state', 'normalize_ssl_mode'), ('mycli.app_state', 'configure_prompt_state'), ('mycli.app_state', 'destructive_keywords_from_config'), ('mycli.app_state', 'llm_prompt_truncation')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mysql_sql_analysis_extracts_tables_and_destructive_queries():
    from mycli.packages.sql_utils import extract_tables, is_destructive

    tables = extract_tables("SELECT u.id FROM app.users AS u JOIN audit.logs l ON u.id = l.user_id")
    assert ("app", "users", "u") in tables
    assert ("audit", "logs", "l") in tables
    assert is_destructive(["drop", "delete"], "DROP TABLE users") is True
    assert is_destructive(["drop", "delete"], "SELECT * FROM users") is False
