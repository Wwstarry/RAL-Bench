from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'fastjsonschema'
CORE_MODULES = ['fastjsonschema', 'fastjsonschema.__main__', 'fastjsonschema.draft04', 'fastjsonschema.draft06', 'fastjsonschema.draft07', 'fastjsonschema.draft2019']
PUBLIC_SYMBOLS = [('fastjsonschema', 'validate'), ('fastjsonschema', 'compile'), ('fastjsonschema', 'compile_to_code'), ('fastjsonschema.__main__', 'main'), ('fastjsonschema.draft04', 'CodeGeneratorDraft04'), ('fastjsonschema.draft06', 'CodeGeneratorDraft06'), ('fastjsonschema.draft07', 'CodeGeneratorDraft07'), ('fastjsonschema.draft2019', 'CodeGeneratorDraft2019')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_compiled_json_schema_accepts_and_rejects_values():
    import fastjsonschema

    validate = fastjsonschema.compile({"type": "object", "required": ["age"], "properties": {"age": {"type": "integer"}}})
    assert validate({"age": 3}) == {"age": 3}
    with pytest.raises(fastjsonschema.JsonSchemaException):
        validate({"age": "three"})
