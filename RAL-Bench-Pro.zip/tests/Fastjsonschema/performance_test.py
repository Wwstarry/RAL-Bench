"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_compiled_json_schema_accepts_and_rejects_values():
    import fastjsonschema

    validate = fastjsonschema.compile({"type": "object", "required": ["age"], "properties": {"age": {"type": "integer"}}})
    assert validate({"age": 3}) == {"age": 3}
    with pytest.raises(fastjsonschema.JsonSchemaException):
        validate({"age": "three"})
