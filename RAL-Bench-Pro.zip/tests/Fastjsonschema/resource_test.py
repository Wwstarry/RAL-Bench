"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_compiled_json_schema_accepts_and_rejects_values():
    import fastjsonschema

    validate = fastjsonschema.compile({"type": "object", "required": ["age"], "properties": {"age": {"type": "integer"}}})
    assert validate({"age": 3}) == {"age": 3}
    with pytest.raises(fastjsonschema.JsonSchemaException):
        validate({"age": "three"})
