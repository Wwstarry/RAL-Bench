"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_numerical_units_evaluates_expressions_in_si_mode():
    import numericalunits as nu

    nu.reset_units("SI")
    assert nu.nu_eval("2 * m / s") == 2.0
    assert nu.nu_eval("1 * km") == 1000.0
