"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_numerical_units_evaluates_expressions_in_si_mode():
    import numericalunits as nu

    nu.reset_units("SI")
    assert nu.nu_eval("2 * m / s") == 2.0
    assert nu.nu_eval("1 * km") == 1000.0
