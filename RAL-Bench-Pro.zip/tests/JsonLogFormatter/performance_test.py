"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_json_log_formatter_serializes_message_and_extra_fields():
    import json
    import logging
    from json_log_formatter import JSONFormatter

    record = logging.LogRecord("demo", logging.INFO, __file__, 1, "hello", (), None)
    record.request_id = "abc"
    data = json.loads(JSONFormatter().format(record))
    assert data["message"] == "hello"
    assert data["request_id"] == "abc"
