"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_dotdrop_list_and_content_helpers():
    from dotdrop.utils import content_empty, uniq_list

    assert uniq_list(["a", "b", "a", "c", "b"]) == ["a", "b", "c"]
    assert content_empty("") is True
    assert content_empty(b"\n") is True
    assert content_empty(" value ") is False
