"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_dotdrop_list_and_content_helpers():
    from dotdrop.utils import content_empty, uniq_list

    assert uniq_list(["a", "b", "a", "c", "b"]) == ["a", "b", "c"]
    assert content_empty("") is True
    assert content_empty(b"\n") is True
    assert content_empty(" value ") is False
