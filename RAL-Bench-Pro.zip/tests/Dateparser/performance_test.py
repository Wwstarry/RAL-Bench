"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_human_date_parsing_with_explicit_timezone():
    import dateparser

    value = dateparser.parse("12 March 2025 14:30 UTC")
    assert value.year == 2025
    assert value.month == 3
    assert value.day == 12
    assert value.hour == 14
