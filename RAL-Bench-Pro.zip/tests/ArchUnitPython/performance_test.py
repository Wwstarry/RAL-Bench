"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_architecture_path_helpers_normalize_and_split_paths():
    from archunitpython.common.pattern_matching import extract_filename, normalize_path, path_without_filename

    assert normalize_path(r"src\pkg\module.py") == "src/pkg/module.py"
    assert extract_filename("src/pkg/module.py") == "module.py"
    assert path_without_filename("src/pkg/module.py") == "src/pkg"
