from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'archunitpython'
CORE_MODULES = ['archunitpython', 'archunitpython.common', 'archunitpython.files', 'archunitpython.graph', 'archunitpython.layers', 'archunitpython.metrics']
PUBLIC_SYMBOLS = [('archunitpython.common.pattern_matching', 'normalize_path'), ('archunitpython.common.pattern_matching', 'extract_filename'), ('archunitpython.common.pattern_matching', 'path_without_filename'), ('archunitpython.common.pattern_matching', 'matches_pattern'), ('archunitpython.common.pattern_matching', 'matches_pattern_classname'), ('archunitpython.common.pattern_matching', 'matches_all_patterns'), ('archunitpython.common.pattern_matching', 'matches_any_pattern'), ('archunitpython.common.regex_factory', 'RegexFactory'), ('archunitpython.common.types', 'PatternMatchingOptions'), ('archunitpython.common.types', 'Filter'), ('archunitpython.graph.graph_reporter', 'FolderDepthCollapse'), ('archunitpython.graph.graph_reporter', 'PatternCollapse'), ('archunitpython.graph.graph_reporter', 'GraphQueryOptions'), ('archunitpython.graph.graph_reporter', 'GraphReportNode'), ('archunitpython.graph.graph_reporter', 'GraphReportEdge'), ('archunitpython.graph.graph_reporter', 'GraphReportSummary'), ('archunitpython.graph.graph_reporter', 'GraphReportSnapshot'), ('archunitpython.graph.graph_reporter', 'ProjectGraphBuilder')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_architecture_path_helpers_normalize_and_split_paths():
    from archunitpython.common.pattern_matching import extract_filename, normalize_path, path_without_filename

    assert normalize_path(r"src\pkg\module.py") == "src/pkg/module.py"
    assert extract_filename("src/pkg/module.py") == "module.py"
    assert path_without_filename("src/pkg/module.py") == "src/pkg"
