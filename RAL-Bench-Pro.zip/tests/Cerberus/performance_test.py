"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_cerberus_validates_types_ranges_and_required_fields():
    from cerberus import Validator

    validator = Validator({"age": {"type": "integer", "min": 0, "required": True}})
    assert validator.validate({"age": 36}) is True
    assert validator.validate({"age": -1}) is False
    assert "age" in validator.errors
