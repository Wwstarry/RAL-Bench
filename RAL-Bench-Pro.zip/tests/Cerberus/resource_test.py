"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_cerberus_validates_types_ranges_and_required_fields():
    from cerberus import Validator

    validator = Validator({"age": {"type": "integer", "min": 0, "required": True}})
    assert validator.validate({"age": 36}) is True
    assert validator.validate({"age": -1}) is False
    assert "age" in validator.errors
