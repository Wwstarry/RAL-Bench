from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cerberus'
CORE_MODULES = ['cerberus', 'cerberus.errors', 'cerberus.schema', 'cerberus.utils', 'cerberus.validator']
PUBLIC_SYMBOLS = [('cerberus.errors', 'ValidationError'), ('cerberus.errors', 'ErrorList'), ('cerberus.errors', 'ErrorTreeNode'), ('cerberus.errors', 'ErrorTree'), ('cerberus.errors', 'DocumentErrorTree'), ('cerberus.errors', 'SchemaErrorTree'), ('cerberus.errors', 'BaseErrorHandler'), ('cerberus.errors', 'ToyErrorHandler'), ('cerberus.errors', 'BasicErrorHandler'), ('cerberus.errors', 'SchemaErrorHandler'), ('cerberus.errors', 'encode_unicode'), ('cerberus.schema', 'SchemaError'), ('cerberus.schema', 'DefinitionSchema'), ('cerberus.schema', 'UnvalidatedSchema'), ('cerberus.schema', 'SchemaValidationSchema'), ('cerberus.schema', 'SchemaValidatorMixin'), ('cerberus.schema', 'Registry'), ('cerberus.schema', 'SchemaRegistry')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_cerberus_validates_types_ranges_and_required_fields():
    from cerberus import Validator

    validator = Validator({"age": {"type": "integer", "min": 0, "required": True}})
    assert validator.validate({"age": 36}) is True
    assert validator.validate({"age": -1}) is False
    assert "age" in validator.errors
