from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'dotbot'
CORE_MODULES = ['dotbot', 'dotbot.messenger', 'dotbot.plugins', 'dotbot.util', 'dotbot.cli', 'dotbot.config']
PUBLIC_SYMBOLS = [('dotbot.cli', 'add_options'), ('dotbot.cli', 'read_config'), ('dotbot.cli', 'main'), ('dotbot.config', 'ConfigReader'), ('dotbot.config', 'ReadingError')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_dotbot_config_reader_combines_yaml_and_json_tasks(tmp_path):
    import json
    from dotbot.config import ConfigReader

    yaml_path = tmp_path / "one.yaml"
    json_path = tmp_path / "two.json"
    yaml_path.write_text("- clean: ['~']\n", encoding="utf-8")
    json_path.write_text(json.dumps([{"link": {"~/.x": "x"}}]), encoding="utf-8")
    assert ConfigReader([str(yaml_path), str(json_path)]).get_config() == [
        {"clean": ["~"]}, {"link": {"~/.x": "x"}}
    ]
