"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_dotbot_config_reader_combines_yaml_and_json_tasks(tmp_path):
    import json
    from dotbot.config import ConfigReader

    yaml_path = tmp_path / "one.yaml"
    json_path = tmp_path / "two.json"
    yaml_path.write_text("- clean: ['~']\n", encoding="utf-8")
    json_path.write_text(json.dumps([{"link": {"~/.x": "x"}}]), encoding="utf-8")
    assert ConfigReader([str(yaml_path), str(json_path)]).get_config() == [
        {"clean": ["~"]}, {"link": {"~/.x": "x"}}
    ]
