from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'isort'
CORE_MODULES = ['isort', 'isort.stdlibs', 'isort._vendored.tomli', 'isort._parse_utils', 'isort.api', 'isort.comments']
PUBLIC_SYMBOLS = [('isort._parse_utils', 'NormalizeLineResult'), ('isort._parse_utils', 'SkipLineResult'), ('isort._parse_utils', 'ExtraLine'), ('isort._parse_utils', 'ImportContinuationResult'), ('isort._parse_utils', 'normalize_line'), ('isort._parse_utils', 'strip_syntax'), ('isort._parse_utils', 'skip_line'), ('isort._parse_utils', 'collect_import_continuation'), ('isort._parse_utils', 'normalize_from_import_string'), ('isort._parse_utils', 'import_type'), ('isort.api', 'ImportKey'), ('isort.api', 'sort_code_string'), ('isort.api', 'check_code_string'), ('isort.api', 'sort_stream'), ('isort.api', 'check_stream'), ('isort.api', 'check_file'), ('isort.api', 'sort_file'), ('isort.api', 'find_imports_in_code')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_isort_sorts_import_groups():
    import isort

    source = "import sys\nimport os\n\nimport requests\n"
    result = isort.code(source)
    assert result.index("import os") < result.index("import sys")
