"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_isort_sorts_import_groups():
    import isort

    source = "import sys\nimport os\n\nimport requests\n"
    result = isort.code(source)
    assert result.index("import os") < result.index("import sys")
