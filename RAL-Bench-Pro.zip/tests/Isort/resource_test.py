"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_isort_sorts_import_groups():
    import isort

    source = "import sys\nimport os\n\nimport requests\n"
    result = isort.code(source)
    assert result.index("import os") < result.index("import sys")
