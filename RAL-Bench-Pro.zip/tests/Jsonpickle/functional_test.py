from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jsonpickle'
CORE_MODULES = ['jsonpickle', 'jsonpickle.ext', 'jsonpickle.backend', 'jsonpickle.compat', 'jsonpickle.errors', 'jsonpickle.handlers']
PUBLIC_SYMBOLS = [('jsonpickle.backend', 'JSONBackend'), ('jsonpickle.compat', 'iterator'), ('jsonpickle.errors', 'ClassNotFoundError'), ('jsonpickle.handlers', 'Registry'), ('jsonpickle.handlers', 'BaseHandler'), ('jsonpickle.handlers', 'ArrayHandler'), ('jsonpickle.handlers', 'DatetimeHandler'), ('jsonpickle.handlers', 'RegexHandler'), ('jsonpickle.handlers', 'QueueHandler'), ('jsonpickle.handlers', 'CloneFactory'), ('jsonpickle.handlers', 'UUIDHandler'), ('jsonpickle.handlers', 'LockHandler'), ('jsonpickle.handlers', 'TextIOHandler'), ('jsonpickle.handlers', 'handler_accepts_handler_context'), ('jsonpickle.pickler', 'Pickler'), ('jsonpickle.pickler', 'encode'), ('jsonpickle.unpickler', 'Unpickler'), ('jsonpickle.unpickler', 'decode')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_jsonpickle_round_trips_custom_python_objects():
    import jsonpickle

    class Point:
        def __init__(self, x, y):
            self.x, self.y = x, y

    restored = jsonpickle.decode(jsonpickle.encode({1, 2, 3}))
    assert restored == {1, 2, 3}
