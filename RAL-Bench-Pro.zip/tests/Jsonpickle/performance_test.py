"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_jsonpickle_round_trips_custom_python_objects():
    import jsonpickle

    class Point:
        def __init__(self, x, y):
            self.x, self.y = x, y

    restored = jsonpickle.decode(jsonpickle.encode({1, 2, 3}))
    assert restored == {1, 2, 3}
