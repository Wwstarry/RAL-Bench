"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_jsonpickle_round_trips_custom_python_objects():
    import jsonpickle

    class Point:
        def __init__(self, x, y):
            self.x, self.y = x, y

    restored = jsonpickle.decode(jsonpickle.encode({1, 2, 3}))
    assert restored == {1, 2, 3}
