"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_icalendar_serializes_and_parses_events():
    from datetime import date
    from icalendar import Calendar, Event

    calendar = Calendar()
    event = Event()
    event.add("summary", "Demo")
    event.add("dtstart", date(2025, 1, 2))
    calendar.add_component(event)
    parsed = Calendar.from_ical(calendar.to_ical()).walk("VEVENT")[0]
    assert str(parsed["SUMMARY"]) == "Demo"
    assert parsed.decoded("DTSTART") == date(2025, 1, 2)
