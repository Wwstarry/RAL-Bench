from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'icalendar'
CORE_MODULES = ['icalendar', 'icalendar.cal', 'icalendar.parser', 'icalendar.prop', 'icalendar.timezone', 'icalendar.parser.ical']
PUBLIC_SYMBOLS = [('icalendar.timezone', 'use_pytz'), ('icalendar.timezone', 'use_zoneinfo'), ('icalendar.alarms', 'AlarmTime'), ('icalendar.alarms', 'Alarms'), ('icalendar.attr', 'multi_language_text_property'), ('icalendar.attr', 'single_int_property'), ('icalendar.attr', 'single_utc_property'), ('icalendar.attr', 'single_string_property'), ('icalendar.attr', 'create_single_property'), ('icalendar.attr', 'property_get_duration'), ('icalendar.attr', 'property_set_duration'), ('icalendar.attr', 'property_del_duration'), ('icalendar.attr', 'duration_property'), ('icalendar.attr', 'multi_text_property'), ('icalendar.attr', 'single_string_enum_property'), ('icalendar.attr', 'timezone_datetime_property'), ('icalendar.attr', 'rfc_7953_duration_property'), ('icalendar.attr', 'rfc_7953_end_property')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_icalendar_serializes_and_parses_events():
    from datetime import date
    from icalendar import Calendar, Event

    calendar = Calendar()
    event = Event()
    event.add("summary", "Demo")
    event.add("dtstart", date(2025, 1, 2))
    calendar.add_component(event)
    parsed = Calendar.from_ical(calendar.to_ical()).walk("VEVENT")[0]
    assert str(parsed["SUMMARY"]) == "Demo"
    assert parsed.decoded("DTSTART") == date(2025, 1, 2)
