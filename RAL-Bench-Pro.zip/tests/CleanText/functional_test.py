from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cleantext'
CORE_MODULES = ['cleantext', 'cleantext.clean', 'cleantext.specials', 'cleantext.utils']
PUBLIC_SYMBOLS = [('cleantext.clean', 'fix_strange_quotes'), ('cleantext.clean', 'fix_bad_unicode'), ('cleantext.clean', 'to_ascii_unicode'), ('cleantext.clean', 'normalize_whitespace'), ('cleantext.clean', 'replace_urls'), ('cleantext.clean', 'replace_emails'), ('cleantext.clean', 'replace_phone_numbers'), ('cleantext.clean', 'replace_ip_addresses'), ('cleantext.clean', 'replace_numbers'), ('cleantext.clean', 'replace_digits'), ('cleantext.clean', 'replace_currency_symbols'), ('cleantext.clean', 'replace_punct'), ('cleantext.clean', 'remove_punct'), ('cleantext.clean', 'replace_code'), ('cleantext.clean', 'replace_file_paths'), ('cleantext.clean', 'remove_emoji'), ('cleantext.clean', 'clean'), ('cleantext.clean', 'clean_texts')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_clean_text_normalizes_unicode_urls_and_whitespace():
    from cleantext import clean

    result = clean("  Héllo   https://example.test  ", lower=True, no_urls=True)
    assert "<url>" in result
    assert result.startswith("hello")
    assert "  " not in result
