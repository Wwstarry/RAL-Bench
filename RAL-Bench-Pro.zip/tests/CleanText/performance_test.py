"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_clean_text_normalizes_unicode_urls_and_whitespace():
    from cleantext import clean

    result = clean("  Héllo   https://example.test  ", lower=True, no_urls=True)
    assert "<url>" in result
    assert result.startswith("hello")
    assert "  " not in result
