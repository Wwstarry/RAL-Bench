"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_clean_text_normalizes_unicode_urls_and_whitespace():
    from cleantext import clean

    result = clean("  Héllo   https://example.test  ", lower=True, no_urls=True)
    assert "<url>" in result
    assert result.startswith("hello")
    assert "  " not in result
