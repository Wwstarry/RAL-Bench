"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_persian_converts_digits_and_normalizes_arabic_characters():
    import persian

    assert persian.convert_en_numbers("Price 123") == "Price ۱۲۳"
    assert persian.convert_ar_characters("ي ك") == "ی ک"
