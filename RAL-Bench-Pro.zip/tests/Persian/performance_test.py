"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_persian_converts_digits_and_normalizes_arabic_characters():
    import persian

    assert persian.convert_en_numbers("Price 123") == "Price ۱۲۳"
    assert persian.convert_ar_characters("ي ك") == "ی ک"
