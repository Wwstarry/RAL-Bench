from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'persian'
CORE_MODULES = ['persian', 'persian.core', 'persian.deprecation']
PUBLIC_SYMBOLS = [('persian.core', 'convert_en_numbers'), ('persian.core', 'convert_en_characters'), ('persian.core', 'convert_ar_numbers'), ('persian.core', 'convert_fa_numbers'), ('persian.core', 'convert_ar_characters'), ('persian.core', 'convert_fa_spaces'), ('persian.core', 'decode_url'), ('persian.core', 'normalize_persian'), ('persian.core', 'contains_persian_digits'), ('persian.core', 'contains_arabic_digits'), ('persian.core', 'is_persian_text'), ('persian.core', 'remove_arabic_diacritics'), ('persian.deprecation', 'enToPersianNumb'), ('persian.deprecation', 'enToPersianChar'), ('persian.deprecation', 'arToPersianNumb'), ('persian.deprecation', 'arToPersianChar')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_persian_converts_digits_and_normalizes_arabic_characters():
    import persian

    assert persian.convert_en_numbers("Price 123") == "Price ۱۲۳"
    assert persian.convert_ar_characters("ي ك") == "ی ک"
