from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'ioc_finder'
CORE_MODULES = ['ioc_finder', 'ioc_finder.ioc_finder', 'ioc_finder.ioc_grammars']
PUBLIC_SYMBOLS = [('ioc_finder.ioc_finder', 'prepare_text'), ('ioc_finder.ioc_finder', 'parse_urls'), ('ioc_finder.ioc_finder', 'parse_urls_complete'), ('ioc_finder.ioc_finder', 'parse_domain_names'), ('ioc_finder.ioc_finder', 'parse_ipv4_addresses'), ('ioc_finder.ioc_finder', 'parse_ipv6_addresses'), ('ioc_finder.ioc_finder', 'parse_socket_addresses'), ('ioc_finder.ioc_finder', 'parse_complete_email_addresses'), ('ioc_finder.ioc_finder', 'parse_email_addresses'), ('ioc_finder.ioc_finder', 'parse_imphashes_'), ('ioc_finder.ioc_finder', 'parse_authentihashes_'), ('ioc_finder.ioc_finder', 'parse_md5s'), ('ioc_finder.ioc_finder', 'parse_sha1s'), ('ioc_finder.ioc_finder', 'parse_sha256s'), ('ioc_finder.ioc_finder', 'parse_sha512s'), ('ioc_finder.ioc_finder', 'parse_ssdeeps'), ('ioc_finder.ioc_finder', 'parse_asns'), ('ioc_finder.ioc_finder', 'parse_cves')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_ioc_finder_extracts_network_and_hash_indicators():
    from ioc_finder import find_iocs

    found = find_iocs("Connect to 192.0.2.1 and example.com; hash d41d8cd98f00b204e9800998ecf8427e")
    assert "192.0.2.1" in found["ipv4s"]
    assert "example.com" in found["domains"]
    assert "d41d8cd98f00b204e9800998ecf8427e" in found["md5s"]
