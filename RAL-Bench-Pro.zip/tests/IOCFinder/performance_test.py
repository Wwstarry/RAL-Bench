"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_ioc_finder_extracts_network_and_hash_indicators():
    from ioc_finder import find_iocs

    found = find_iocs("Connect to 192.0.2.1 and example.com; hash d41d8cd98f00b204e9800998ecf8427e")
    assert "192.0.2.1" in found["ipv4s"]
    assert "example.com" in found["domains"]
    assert "d41d8cd98f00b204e9800998ecf8427e" in found["md5s"]
