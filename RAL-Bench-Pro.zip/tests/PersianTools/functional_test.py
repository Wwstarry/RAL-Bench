from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'persiantools'
CORE_MODULES = ['persiantools', 'persiantools.characters', 'persiantools.digits', 'persiantools.jdatetime', 'persiantools.utils']
PUBLIC_SYMBOLS = [('persiantools.characters', 'ar_to_fa'), ('persiantools.characters', 'fa_to_ar'), ('persiantools.digits', 'OutOfRangeException'), ('persiantools.digits', 'en_to_fa'), ('persiantools.digits', 'ar_to_fa'), ('persiantools.digits', 'fa_to_en'), ('persiantools.digits', 'fa_to_ar'), ('persiantools.digits', 'to_word'), ('persiantools.jdatetime', 'JalaliDate'), ('persiantools.jdatetime', 'JalaliDateTime'), ('persiantools.utils', 'replace')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_persian_tools_converts_digits_and_calendar_dates():
    from persiantools.digits import en_to_fa, fa_to_en
    from persiantools.jdatetime import JalaliDate

    assert en_to_fa("123") == "۱۲۳"
    assert fa_to_en("۱۲۳") == "123"
    assert JalaliDate(1403, 1, 1).to_gregorian().isoformat() == "2024-03-20"
