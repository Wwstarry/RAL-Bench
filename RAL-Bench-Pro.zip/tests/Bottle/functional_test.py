from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'bottle'
CORE_MODULES = ['bottle']
PUBLIC_SYMBOLS = [('bottle', 'DictProperty'), ('bottle', 'cached_property'), ('bottle', 'lazy_attribute'), ('bottle', 'BottleException'), ('bottle', 'RouteError'), ('bottle', 'RouterUnknownModeError'), ('bottle', 'RouteSyntaxError'), ('bottle', 'RouteBuildError'), ('bottle', 'Router'), ('bottle', 'Route'), ('bottle', 'Bottle'), ('bottle', 'BaseRequest'), ('bottle', 'HeaderProperty'), ('bottle', 'BaseResponse'), ('bottle', 'LocalRequest'), ('bottle', 'LocalResponse'), ('bottle', 'HTTPResponse'), ('bottle', 'HTTPError')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_bottle_route_matches_dynamic_path():
    import json
    import bottle

    app = bottle.Bottle()

    @app.get("/hello/<name>")
    def hello(name):
        return {"name": name}

    route, args = app.router.match({"PATH_INFO": "/hello/Ada", "REQUEST_METHOD": "GET"})
    assert json.loads(route.call(**args)) == {"name": "Ada"}
