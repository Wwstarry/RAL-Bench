"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_bottle_route_matches_dynamic_path():
    import json
    import bottle

    app = bottle.Bottle()

    @app.get("/hello/<name>")
    def hello(name):
        return {"name": name}

    route, args = app.router.match({"PATH_INFO": "/hello/Ada", "REQUEST_METHOD": "GET"})
    assert json.loads(route.call(**args)) == {"name": "Ada"}
