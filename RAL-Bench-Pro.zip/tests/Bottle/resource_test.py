"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_bottle_route_matches_dynamic_path():
    import json
    import bottle

    app = bottle.Bottle()

    @app.get("/hello/<name>")
    def hello(name):
        return {"name": name}

    route, args = app.router.match({"PATH_INFO": "/hello/Ada", "REQUEST_METHOD": "GET"})
    assert json.loads(route.call(**args)) == {"name": "Ada"}
