"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_local_query_parser_resolves_path_and_slug(tmp_path):
    from gitingest.query_parser import parse_local_dir_path

    project = tmp_path / "demo"
    project.mkdir()
    query = parse_local_dir_path(str(project))
    assert query.local_path == project.resolve()
    assert query.slug.endswith("demo")
    assert query.url is None
