from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'gitingest'
CORE_MODULES = ['gitingest', 'gitingest.schemas', 'gitingest.utils', 'gitingest.__main__', 'gitingest.clone', 'gitingest.entrypoint']
PUBLIC_SYMBOLS = [('gitingest.__main__', 'main'), ('gitingest.clone', 'clone_repo'), ('gitingest.entrypoint', 'ingest_async'), ('gitingest.entrypoint', 'ingest')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_local_query_parser_resolves_path_and_slug(tmp_path):
    from gitingest.query_parser import parse_local_dir_path

    project = tmp_path / "demo"
    project.mkdir()
    query = parse_local_dir_path(str(project))
    assert query.local_path == project.resolve()
    assert query.slug.endswith("demo")
    assert query.url is None
