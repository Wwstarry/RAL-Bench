"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_local_query_parser_resolves_path_and_slug(tmp_path):
    from gitingest.query_parser import parse_local_dir_path

    project = tmp_path / "demo"
    project.mkdir()
    query = parse_local_dir_path(str(project))
    assert query.local_path == project.resolve()
    assert query.slug.endswith("demo")
    assert query.url is None
