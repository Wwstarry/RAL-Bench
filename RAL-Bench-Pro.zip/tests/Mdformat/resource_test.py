"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mdformat_normalizes_headings_and_list_spacing():
    import mdformat

    rendered = mdformat.text("#  Hello\n\n* one\n* two\n")
    assert rendered.startswith("# Hello\n")
    assert "- one\n- two" in rendered
