from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mdformat'
CORE_MODULES = ['mdformat', 'mdformat.codepoints', 'mdformat.renderer', 'mdformat.__main__', 'mdformat._api', 'mdformat._cli']
PUBLIC_SYMBOLS = [('mdformat.renderer', 'MDRenderer'), ('mdformat.__main__', 'run'), ('mdformat._api', 'text'), ('mdformat._api', 'file'), ('mdformat._cli', 'RendererWarningPrinter'), ('mdformat._cli', 'InvalidPath'), ('mdformat._cli', 'run'), ('mdformat._cli', 'validate_wrap_arg'), ('mdformat._cli', 'make_arg_parser'), ('mdformat._cli', 'separate_core_and_plugin_opts'), ('mdformat._cli', 'resolve_file_paths'), ('mdformat._cli', 'is_excluded'), ('mdformat._cli', 'print_paragraphs'), ('mdformat._cli', 'print_error'), ('mdformat._cli', 'cached_textwrapper'), ('mdformat._cli', 'wrap_paragraphs'), ('mdformat._cli', 'log_handler_applied'), ('mdformat._cli', 'get_plugin_info_str')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mdformat_normalizes_headings_and_list_spacing():
    import mdformat

    rendered = mdformat.text("#  Hello\n\n* one\n* two\n")
    assert rendered.startswith("# Hello\n")
    assert "- one\n- two" in rendered
