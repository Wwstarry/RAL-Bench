"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mdformat_normalizes_headings_and_list_spacing():
    import mdformat

    rendered = mdformat.text("#  Hello\n\n* one\n* two\n")
    assert rendered.startswith("# Hello\n")
    assert "- one\n- two" in rendered
