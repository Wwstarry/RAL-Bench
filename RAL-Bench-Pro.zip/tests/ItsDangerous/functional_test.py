from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'itsdangerous'
CORE_MODULES = ['itsdangerous', 'itsdangerous.encoding', 'itsdangerous.exc', 'itsdangerous.serializer', 'itsdangerous.signer', 'itsdangerous.timed']
PUBLIC_SYMBOLS = [('itsdangerous.encoding', 'want_bytes'), ('itsdangerous.encoding', 'base64_encode'), ('itsdangerous.encoding', 'base64_decode'), ('itsdangerous.encoding', 'int_to_bytes'), ('itsdangerous.encoding', 'bytes_to_int'), ('itsdangerous.exc', 'BadData'), ('itsdangerous.exc', 'BadSignature'), ('itsdangerous.exc', 'BadTimeSignature'), ('itsdangerous.exc', 'SignatureExpired'), ('itsdangerous.exc', 'BadHeader'), ('itsdangerous.exc', 'BadPayload'), ('itsdangerous.serializer', 'Serializer'), ('itsdangerous.serializer', 'is_text_serializer'), ('itsdangerous.signer', 'SigningAlgorithm'), ('itsdangerous.signer', 'NoneAlgorithm'), ('itsdangerous.signer', 'HMACAlgorithm'), ('itsdangerous.signer', 'Signer'), ('itsdangerous.timed', 'TimestampSigner')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_url_safe_serializer_signs_and_verifies_payload():
    from itsdangerous import BadSignature, URLSafeSerializer

    serializer = URLSafeSerializer("secret-key", salt="ral-bench")
    token = serializer.dumps({"user": "alice", "admin": False})
    assert serializer.loads(token) == {"user": "alice", "admin": False}
    with pytest.raises(BadSignature):
        serializer.loads(token + "tampered")
