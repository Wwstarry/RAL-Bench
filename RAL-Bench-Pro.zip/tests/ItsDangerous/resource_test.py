"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_url_safe_serializer_signs_and_verifies_payload():
    from itsdangerous import BadSignature, URLSafeSerializer

    serializer = URLSafeSerializer("secret-key", salt="ral-bench")
    token = serializer.dumps({"user": "alice", "admin": False})
    assert serializer.loads(token) == {"user": "alice", "admin": False}
    with pytest.raises(BadSignature):
        serializer.loads(token + "tampered")
