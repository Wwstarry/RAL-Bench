"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_url_safe_serializer_signs_and_verifies_payload():
    from itsdangerous import BadSignature, URLSafeSerializer

    serializer = URLSafeSerializer("secret-key", salt="ral-bench")
    token = serializer.dumps({"user": "alice", "admin": False})
    assert serializer.loads(token) == {"user": "alice", "admin": False}
    with pytest.raises(BadSignature):
        serializer.loads(token + "tampered")
