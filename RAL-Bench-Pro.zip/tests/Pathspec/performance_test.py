"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_gitignore_patterns_match_files_and_negations():
    from pathspec import PathSpec

    spec = PathSpec.from_lines("gitwildmatch", ["*.py", "!keep.py"])
    assert spec.match_file("main.py") is True
    assert spec.match_file("keep.py") is False
    assert spec.match_file("notes.txt") is False
