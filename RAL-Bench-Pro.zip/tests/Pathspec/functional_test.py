from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'pathspec'
CORE_MODULES = ['pathspec', 'pathspec._backends', 'pathspec.patterns', 'pathspec._backends.hyperscan', 'pathspec._backends.re2', 'pathspec._backends.simple']
PUBLIC_SYMBOLS = [('pathspec._typing', 'assert_unreachable'), ('pathspec.gitignore', 'GitIgnoreSpec'), ('pathspec.pathspec', 'PathSpec'), ('pathspec.pattern', 'Pattern'), ('pathspec.pattern', 'RegexPattern'), ('pathspec.pattern', 'RegexMatchResult'), ('pathspec.util', 'AlreadyRegisteredError'), ('pathspec.util', 'RecursionError'), ('pathspec.util', 'CheckResult'), ('pathspec.util', 'MatchDetail'), ('pathspec.util', 'TreeEntry'), ('pathspec.util', 'append_dir_sep'), ('pathspec.util', 'check_match_file'), ('pathspec.util', 'detailed_match_files'), ('pathspec.util', 'iter_tree'), ('pathspec.util', 'iter_tree_entries'), ('pathspec.util', 'iter_tree_files'), ('pathspec.util', 'lookup_pattern')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_gitignore_patterns_match_files_and_negations():
    from pathspec import PathSpec

    spec = PathSpec.from_lines("gitwildmatch", ["*.py", "!keep.py"])
    assert spec.match_file("main.py") is True
    assert spec.match_file("keep.py") is False
    assert spec.match_file("notes.txt") is False
