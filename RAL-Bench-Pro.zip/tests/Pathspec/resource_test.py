"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_gitignore_patterns_match_files_and_negations():
    from pathspec import PathSpec

    spec = PathSpec.from_lines("gitwildmatch", ["*.py", "!keep.py"])
    assert spec.match_file("main.py") is True
    assert spec.match_file("keep.py") is False
    assert spec.match_file("notes.txt") is False
