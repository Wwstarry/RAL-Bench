from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'docstring_parser'
CORE_MODULES = ['docstring_parser', 'docstring_parser.attrdoc', 'docstring_parser.common', 'docstring_parser.epydoc', 'docstring_parser.google', 'docstring_parser.numpydoc']
PUBLIC_SYMBOLS = [('docstring_parser.attrdoc', 'AttributeDocstrings'), ('docstring_parser.attrdoc', 'ast_get_constant_value'), ('docstring_parser.attrdoc', 'ast_unparse'), ('docstring_parser.attrdoc', 'ast_is_literal_str'), ('docstring_parser.attrdoc', 'ast_get_attribute'), ('docstring_parser.attrdoc', 'add_attribute_docstrings'), ('docstring_parser.common', 'ParseError'), ('docstring_parser.common', 'DocstringStyle'), ('docstring_parser.common', 'RenderingStyle'), ('docstring_parser.common', 'DocstringMeta'), ('docstring_parser.common', 'DocstringParam'), ('docstring_parser.common', 'DocstringReturns'), ('docstring_parser.common', 'DocstringRaises'), ('docstring_parser.common', 'DocstringDeprecated'), ('docstring_parser.common', 'DocstringExample'), ('docstring_parser.common', 'Docstring'), ('docstring_parser.epydoc', 'parse'), ('docstring_parser.epydoc', 'compose')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_docstring_parser_extracts_parameters_and_returns():
    from docstring_parser import parse

    parsed = parse("""Add values.\n\nArgs:\n    left: First value.\n    right: Second value.\n\nReturns:\n    The sum.\n""")
    assert parsed.short_description == "Add values."
    assert [param.arg_name for param in parsed.params] == ["left", "right"]
    assert parsed.returns.description == "The sum."
