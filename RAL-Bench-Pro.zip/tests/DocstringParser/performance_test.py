"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_docstring_parser_extracts_parameters_and_returns():
    from docstring_parser import parse

    parsed = parse("""Add values.\n\nArgs:\n    left: First value.\n    right: Second value.\n\nReturns:\n    The sum.\n""")
    assert parsed.short_description == "Add values."
    assert [param.arg_name for param in parsed.params] == ["left", "right"]
    assert parsed.returns.description == "The sum."
