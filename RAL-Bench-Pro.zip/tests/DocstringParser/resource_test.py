"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_docstring_parser_extracts_parameters_and_returns():
    from docstring_parser import parse

    parsed = parse("""Add values.\n\nArgs:\n    left: First value.\n    right: Second value.\n\nReturns:\n    The sum.\n""")
    assert parsed.short_description == "Add values."
    assert [param.arg_name for param in parsed.params] == ["left", "right"]
    assert parsed.returns.description == "The sum."
