from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'crudini'
CORE_MODULES = ['crudini']
PUBLIC_SYMBOLS = [('crudini', 'CrudiniInputFilter'), ('crudini', 'AddDefaultSection'), ('crudini', 'FileLock'), ('crudini', 'LockedFile'), ('crudini', 'CrudiniConfigParser'), ('crudini', 'Print'), ('crudini', 'PrintIni'), ('crudini', 'PrintIniNoSpace'), ('crudini', 'PrintLines'), ('crudini', 'PrintSh'), ('crudini', 'Crudini'), ('crudini', 'env_encoding'), ('crudini', 'error'), ('crudini', 'delete_if_exists'), ('crudini', 'file_is_closed'), ('crudini', 'main')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_crudini_config_parser_round_trip():
    from crudini import CrudiniConfigParser

    parser = CrudiniConfigParser()
    parser.add_section("service")
    parser.set("service", "enabled", "yes")
    assert parser.get("service", "enabled") == "yes"
    assert parser.has_section("service")
