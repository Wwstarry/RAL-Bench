"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_crudini_config_parser_round_trip():
    from crudini import CrudiniConfigParser

    parser = CrudiniConfigParser()
    parser.add_section("service")
    parser.set("service", "enabled", "yes")
    assert parser.get("service", "enabled") == "yes"
    assert parser.has_section("service")
