"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_crudini_config_parser_round_trip():
    from crudini import CrudiniConfigParser

    parser = CrudiniConfigParser()
    parser.add_section("service")
    parser.set("service", "enabled", "yes")
    assert parser.get("service", "enabled") == "yes"
    assert parser.has_section("service")
