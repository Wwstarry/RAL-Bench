"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_cookiecutter_finds_single_template_directory(tmp_path):
    from jinja2 import Environment
    from cookiecutter.find import find_template

    expected = tmp_path / "{{cookiecutter.project_name}}"
    expected.mkdir()
    assert find_template(tmp_path, Environment()) == expected
