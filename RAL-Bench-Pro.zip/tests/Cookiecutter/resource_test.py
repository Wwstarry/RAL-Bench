"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_cookiecutter_finds_single_template_directory(tmp_path):
    from jinja2 import Environment
    from cookiecutter.find import find_template

    expected = tmp_path / "{{cookiecutter.project_name}}"
    expected.mkdir()
    assert find_template(tmp_path, Environment()) == expected
