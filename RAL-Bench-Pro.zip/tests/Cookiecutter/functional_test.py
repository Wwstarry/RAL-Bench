from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cookiecutter'
CORE_MODULES = ['cookiecutter', 'cookiecutter.cli', 'cookiecutter.config', 'cookiecutter.environment', 'cookiecutter.exceptions', 'cookiecutter.extensions']
PUBLIC_SYMBOLS = [('cookiecutter.cli', 'version_msg'), ('cookiecutter.cli', 'validate_extra_context'), ('cookiecutter.cli', 'list_installed_templates'), ('cookiecutter.cli', 'main'), ('cookiecutter.config', 'merge_configs'), ('cookiecutter.config', 'get_config'), ('cookiecutter.config', 'get_user_config'), ('cookiecutter.environment', 'ExtensionLoaderMixin'), ('cookiecutter.environment', 'StrictEnvironment'), ('cookiecutter.exceptions', 'CookiecutterException'), ('cookiecutter.exceptions', 'NonTemplatedInputDirException'), ('cookiecutter.exceptions', 'UnknownTemplateDirException'), ('cookiecutter.exceptions', 'MissingProjectDir'), ('cookiecutter.exceptions', 'ConfigDoesNotExistException'), ('cookiecutter.exceptions', 'InvalidConfiguration'), ('cookiecutter.exceptions', 'UnknownRepoType'), ('cookiecutter.exceptions', 'VCSNotInstalled'), ('cookiecutter.exceptions', 'ContextDecodingException')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_cookiecutter_finds_single_template_directory(tmp_path):
    from jinja2 import Environment
    from cookiecutter.find import find_template

    expected = tmp_path / "{{cookiecutter.project_name}}"
    expected.mkdir()
    assert find_template(tmp_path, Environment()) == expected
