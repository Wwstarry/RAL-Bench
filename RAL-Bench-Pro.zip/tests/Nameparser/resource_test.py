"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_human_name_parser_splits_titles_names_and_suffixes():
    from nameparser import HumanName

    name = HumanName("Dr. Ada Lovelace Jr.")
    assert (name.title, name.first, name.last, name.suffix) == ("Dr.", "Ada", "Lovelace", "Jr.")
