from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'nameparser'
CORE_MODULES = ['nameparser', 'nameparser.config', 'nameparser.__main__', 'nameparser.parser', 'nameparser.util']
PUBLIC_SYMBOLS = [('nameparser.config', 'SetManager'), ('nameparser.config', 'TupleManager'), ('nameparser.config', 'RegexTupleManager'), ('nameparser.config', 'Constants'), ('nameparser.__main__', 'main'), ('nameparser.parser', 'HumanName'), ('nameparser.parser', 'group_contiguous_integers'), ('nameparser.util', 'lc')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_human_name_parser_splits_titles_names_and_suffixes():
    from nameparser import HumanName

    name = HumanName("Dr. Ada Lovelace Jr.")
    assert (name.title, name.first, name.last, name.suffix) == ("Dr.", "Ada", "Lovelace", "Jr.")
