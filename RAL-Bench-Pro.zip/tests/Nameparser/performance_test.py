"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_human_name_parser_splits_titles_names_and_suffixes():
    from nameparser import HumanName

    name = HumanName("Dr. Ada Lovelace Jr.")
    assert (name.title, name.first, name.last, name.suffix) == ("Dr.", "Ada", "Lovelace", "Jr.")
