"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_mt940_amount_parses_currency_and_decimal_value():
    from decimal import Decimal
    from mt940.models import Amount

    amount = Amount("123,45", status="C", currency="EUR")
    assert amount.amount == Decimal("123.45")
    assert amount.currency == "EUR"
