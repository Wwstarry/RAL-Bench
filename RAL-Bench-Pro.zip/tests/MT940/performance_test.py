"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_mt940_amount_parses_currency_and_decimal_value():
    from decimal import Decimal
    from mt940.models import Amount

    amount = Amount("123,45", status="C", currency="EUR")
    assert amount.amount == Decimal("123.45")
    assert amount.currency == "EUR"
