from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'mt940'
CORE_MODULES = ['mt940', 'mt940._types', 'mt940.json', 'mt940.models', 'mt940.parser', 'mt940.processors']
PUBLIC_SYMBOLS = [('mt940._types', 'PreProcessor'), ('mt940._types', 'PostProcessor'), ('mt940.json', 'JSONEncoder'), ('mt940.models', 'Model'), ('mt940.models', 'FixedOffset'), ('mt940.models', 'DateTime'), ('mt940.models', 'Date'), ('mt940.models', 'Amount'), ('mt940.models', 'SumAmount'), ('mt940.models', 'Balance'), ('mt940.models', 'Transaction'), ('mt940.models', 'Transactions'), ('mt940.models', 'TransactionsAndTransaction'), ('mt940.parser', 'parse'), ('mt940.parser', 'parse_statements'), ('mt940.processors', 'add_currency_pre_processor'), ('mt940.processors', 'date_fixup_pre_processor'), ('mt940.processors', 'date_cleanup_post_processor')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_mt940_amount_parses_currency_and_decimal_value():
    from decimal import Decimal
    from mt940.models import Amount

    amount = Amount("123,45", status="C", currency="EUR")
    assert amount.amount == Decimal("123.45")
    assert amount.currency == "EUR"
