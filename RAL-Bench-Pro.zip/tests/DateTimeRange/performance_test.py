"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_datetime_range_contains_points_and_calculates_intersection():
    from datetime import datetime
    from datetimerange import DateTimeRange

    value = DateTimeRange("2025-01-01T00:00:00", "2025-01-03T00:00:00")
    assert datetime(2025, 1, 2) in value
    overlap = value.intersection(DateTimeRange("2025-01-02", "2025-01-04"))
    assert overlap.start_datetime == datetime(2025, 1, 2)
    assert overlap.end_datetime == datetime(2025, 1, 3)
