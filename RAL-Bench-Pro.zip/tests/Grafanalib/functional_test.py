from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'grafanalib'
CORE_MODULES = ['grafanalib', 'grafanalib._gen', 'grafanalib.azuredataexplorer', 'grafanalib.azuremonitor', 'grafanalib.cloudwatch', 'grafanalib.core']
PUBLIC_SYMBOLS = [('grafanalib._gen', 'DashboardEncoder'), ('grafanalib._gen', 'DashboardError'), ('grafanalib._gen', 'AlertGroupError'), ('grafanalib._gen', 'DefinitionError'), ('grafanalib._gen', 'write_dashboard'), ('grafanalib._gen', 'loader'), ('grafanalib._gen', 'run_script'), ('grafanalib._gen', 'print_alertgroup'), ('grafanalib._gen', 'write_alertgroups'), ('grafanalib._gen', 'get_alertgroup_json_path'), ('grafanalib._gen', 'alertgroup_path'), ('grafanalib._gen', 'generate_alertgroups'), ('grafanalib._gen', 'generate_alertgroup'), ('grafanalib._gen', 'generate_alertgroups_script'), ('grafanalib._gen', 'generate_alertgroup_script'), ('grafanalib._gen', 'print_dashboard'), ('grafanalib._gen', 'write_dashboards'), ('grafanalib._gen', 'get_dashboard_json_path')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_dashboard_serializes_core_metadata():
    from grafanalib.core import Dashboard

    data = Dashboard(title="Operations", tags=["prod"], uid="ops").to_json_data()
    assert data["title"] == "Operations"
    assert data["tags"] == ["prod"]
    assert data["uid"] == "ops"
    assert data["panels"] == []
