"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_dashboard_serializes_core_metadata():
    from grafanalib.core import Dashboard

    data = Dashboard(title="Operations", tags=["prod"], uid="ops").to_json_data()
    assert data["title"] == "Operations"
    assert data["tags"] == ["prod"]
    assert data["uid"] == "ops"
    assert data["panels"] == []
