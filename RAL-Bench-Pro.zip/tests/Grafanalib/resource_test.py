"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_dashboard_serializes_core_metadata():
    from grafanalib.core import Dashboard

    data = Dashboard(title="Operations", tags=["prod"], uid="ops").to_json_data()
    assert data["title"] == "Operations"
    assert data["tags"] == ["prod"]
    assert data["uid"] == "ops"
    assert data["panels"] == []
