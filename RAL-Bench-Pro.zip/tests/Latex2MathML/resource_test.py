"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_latex_converter_builds_mathml_for_fractions_and_powers():
    from latex2mathml.converter import convert

    rendered = convert(r"\frac{x^2}{2}")
    assert "<mfrac>" in rendered
    assert "<msup>" in rendered
