"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_latex_converter_builds_mathml_for_fractions_and_powers():
    from latex2mathml.converter import convert

    rendered = convert(r"\frac{x^2}{2}")
    assert "<mfrac>" in rendered
    assert "<msup>" in rendered
