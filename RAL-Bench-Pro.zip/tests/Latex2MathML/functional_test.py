from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'latex2mathml'
CORE_MODULES = ['latex2mathml', 'latex2mathml.commands', 'latex2mathml.converter', 'latex2mathml.exceptions', 'latex2mathml.symbols_parser', 'latex2mathml.tokenizer']
PUBLIC_SYMBOLS = [('latex2mathml.commands', 'font_factory'), ('latex2mathml.converter', 'Mode'), ('latex2mathml.converter', 'Converter'), ('latex2mathml.converter', 'convert'), ('latex2mathml.converter', 'convert_to_element'), ('latex2mathml.converter', 'main'), ('latex2mathml.exceptions', 'NumeratorNotFoundError'), ('latex2mathml.exceptions', 'DenominatorNotFoundError'), ('latex2mathml.exceptions', 'ExtraLeftOrMissingRightError'), ('latex2mathml.exceptions', 'MissingSuperScriptOrSubscriptError'), ('latex2mathml.exceptions', 'DoubleSubscriptsError'), ('latex2mathml.exceptions', 'DoubleSuperscriptsError'), ('latex2mathml.exceptions', 'NoAvailableTokensError'), ('latex2mathml.exceptions', 'InvalidStyleForGenfracError'), ('latex2mathml.exceptions', 'MissingEndError'), ('latex2mathml.exceptions', 'InvalidAlignmentError'), ('latex2mathml.exceptions', 'InvalidWidthError'), ('latex2mathml.exceptions', 'LimitsMustFollowMathOperatorError')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_latex_converter_builds_mathml_for_fractions_and_powers():
    from latex2mathml.converter import convert

    rendered = convert(r"\frac{x^2}{2}")
    assert "<mfrac>" in rendered
    assert "<msup>" in rendered
