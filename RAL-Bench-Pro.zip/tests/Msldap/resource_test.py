"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_ldap_target_parses_protocol_port_tree_and_query_options():
    from msldap.commons.target import MSLDAPTarget

    target = MSLDAPTarget.from_url("ldaps://server.example:7636/DC=example,DC=test/?pagesize=250&rate=2")
    assert target.port == 7636
    assert target.tree == "/DC=example,DC=test/"
    assert target.ldap_query_page_size == 250
    assert target.ldap_query_ratelimit == 2
    assert target.is_ssl() is True
