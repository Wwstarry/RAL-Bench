from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'msldap'
CORE_MODULES = ['msldap', 'msldap.commons', 'msldap.external', 'msldap.ldap_objects', 'msldap.network', 'msldap.protocol']
PUBLIC_SYMBOLS = []


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_ldap_target_parses_protocol_port_tree_and_query_options():
    from msldap.commons.target import MSLDAPTarget

    target = MSLDAPTarget.from_url("ldaps://server.example:7636/DC=example,DC=test/?pagesize=250&rate=2")
    assert target.port == 7636
    assert target.tree == "/DC=example,DC=test/"
    assert target.ldap_query_page_size == 250
    assert target.ldap_query_ratelimit == 2
    assert target.is_ssl() is True
