from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cxxheaderparser'
CORE_MODULES = ['cxxheaderparser', 'cxxheaderparser._ply', 'cxxheaderparser.dump', 'cxxheaderparser.errors', 'cxxheaderparser.gentest', 'cxxheaderparser.lexer']
PUBLIC_SYMBOLS = [('cxxheaderparser.dump', 'dumpmain'), ('cxxheaderparser.errors', 'CxxParseError'), ('cxxheaderparser.gentest', 'nondefault_repr'), ('cxxheaderparser.gentest', 'gentest'), ('cxxheaderparser.lexer', 'LexError'), ('cxxheaderparser.lexer', 'Location'), ('cxxheaderparser.lexer', 'LexToken'), ('cxxheaderparser.lexer', 'PlyLexer'), ('cxxheaderparser.lexer', 'TokenStream'), ('cxxheaderparser.lexer', 'LexerTokenStream'), ('cxxheaderparser.lexer', 'BoundedTokenStream'), ('cxxheaderparser.options', 'ParserOptions'), ('cxxheaderparser.parser', 'CxxParser'), ('cxxheaderparser.parserstate', 'ParsedTypeModifiers'), ('cxxheaderparser.parserstate', 'BaseState'), ('cxxheaderparser.parserstate', 'ExternBlockState'), ('cxxheaderparser.parserstate', 'NamespaceBlockState'), ('cxxheaderparser.parserstate', 'ClassBlockState')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_cpp_header_parser_extracts_class_fields():
    from cxxheaderparser.simple import parse_string

    parsed = parse_string("struct Point { int x; int y; };")
    point = parsed.namespace.classes[0]
    assert point.class_decl.typename.segments[0].name == "Point"
    assert [field.name for field in point.fields] == ["x", "y"]
