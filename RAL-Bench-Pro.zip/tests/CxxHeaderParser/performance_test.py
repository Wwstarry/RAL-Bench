"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_cpp_header_parser_extracts_class_fields():
    from cxxheaderparser.simple import parse_string

    parsed = parse_string("struct Point { int x; int y; };")
    point = parsed.namespace.classes[0]
    assert point.class_decl.typename.segments[0].name == "Point"
    assert [field.name for field in point.fields] == ["x", "y"]
