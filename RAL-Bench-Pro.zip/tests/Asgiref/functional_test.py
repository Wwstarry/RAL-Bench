from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'asgiref'
CORE_MODULES = ['asgiref', 'asgiref.compatibility', 'asgiref.current_thread_executor', 'asgiref.local', 'asgiref.server', 'asgiref.sync']
PUBLIC_SYMBOLS = [('asgiref.compatibility', 'is_double_callable'), ('asgiref.compatibility', 'double_to_single_callable'), ('asgiref.compatibility', 'guarantee_single_callable'), ('asgiref.current_thread_executor', 'CurrentThreadExecutor'), ('asgiref.local', 'Local'), ('asgiref.server', 'StatelessServer'), ('asgiref.sync', 'AsyncSingleThreadContext'), ('asgiref.sync', 'ThreadSensitiveContext'), ('asgiref.sync', 'AsyncToSync'), ('asgiref.sync', 'SyncToAsync'), ('asgiref.sync', 'async_to_sync'), ('asgiref.sync', 'sync_to_async'), ('asgiref.testing', 'ApplicationCommunicator'), ('asgiref.timeout', 'timeout'), ('asgiref.typing', 'ASGIVersions'), ('asgiref.typing', 'HTTPScope'), ('asgiref.typing', 'WebSocketScope'), ('asgiref.typing', 'LifespanScope')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_asgiref_bridges_async_and_sync_callables():
    from asgiref.sync import async_to_sync, sync_to_async

    async def add(left, right):
        return left + right

    assert async_to_sync(add)(2, 3) == 5
    assert async_to_sync(sync_to_async(lambda value: value * 2))(4) == 8
