"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_asgiref_bridges_async_and_sync_callables():
    from asgiref.sync import async_to_sync, sync_to_async

    async def add(left, right):
        return left + right

    assert async_to_sync(add)(2, 3) == 5
    assert async_to_sync(sync_to_async(lambda value: value * 2))(4) == 8
