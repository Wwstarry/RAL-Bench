"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_template_rendering_handles_loops_and_escaping():
    from jinja2 import Environment, select_autoescape

    env = Environment(autoescape=select_autoescape(default=True))
    template = env.from_string("{% for item in items %}{{ item }}{% endfor %}")
    assert template.render(items=["<a>", "b"]) == "&lt;a&gt;b"
