from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jinja2'
CORE_MODULES = ['jinja2', 'jinja2.async_utils', 'jinja2.bccache', 'jinja2.compiler', 'jinja2.debug', 'jinja2.environment']
PUBLIC_SYMBOLS = [('jinja2.async_utils', 'async_variant'), ('jinja2.async_utils', 'auto_await'), ('jinja2.async_utils', 'auto_aiter'), ('jinja2.async_utils', 'auto_to_list'), ('jinja2.bccache', 'Bucket'), ('jinja2.bccache', 'BytecodeCache'), ('jinja2.bccache', 'FileSystemBytecodeCache'), ('jinja2.bccache', 'MemcachedBytecodeCache'), ('jinja2.compiler', 'MacroRef'), ('jinja2.compiler', 'Frame'), ('jinja2.compiler', 'VisitorExit'), ('jinja2.compiler', 'DependencyFinderVisitor'), ('jinja2.compiler', 'UndeclaredNameVisitor'), ('jinja2.compiler', 'CompilerExit'), ('jinja2.compiler', 'CodeGenerator'), ('jinja2.compiler', 'optimizeconst'), ('jinja2.compiler', 'generate'), ('jinja2.compiler', 'has_safe_repr')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_template_rendering_handles_loops_and_escaping():
    from jinja2 import Environment, select_autoescape

    env = Environment(autoescape=select_autoescape(default=True))
    template = env.from_string("{% for item in items %}{{ item }}{% endfor %}")
    assert template.render(items=["<a>", "b"]) == "&lt;a&gt;b"
