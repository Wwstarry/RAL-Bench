"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_http_url_headers_and_query_encoding():
    import httpx

    request = httpx.Request("GET", "https://example.test/items", params={"q": "a b"}, headers={"X-Test": "yes"})
    assert str(request.url) == "https://example.test/items?q=a+b"
    assert request.headers["x-test"] == "yes"
