"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_http_url_headers_and_query_encoding():
    import httpx

    request = httpx.Request("GET", "https://example.test/items", params={"q": "a b"}, headers={"X-Test": "yes"})
    assert str(request.url) == "https://example.test/items?q=a+b"
    assert request.headers["x-test"] == "yes"
