from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'httpx'
CORE_MODULES = ['httpx', 'httpx._transports', 'httpx._api', 'httpx._auth', 'httpx._client', 'httpx._config']
PUBLIC_SYMBOLS = [('httpx._api', 'request'), ('httpx._api', 'stream'), ('httpx._api', 'get'), ('httpx._api', 'options'), ('httpx._api', 'head'), ('httpx._api', 'post'), ('httpx._api', 'put'), ('httpx._api', 'patch'), ('httpx._api', 'delete'), ('httpx._auth', 'Auth'), ('httpx._auth', 'FunctionAuth'), ('httpx._auth', 'BasicAuth'), ('httpx._auth', 'NetRCAuth'), ('httpx._auth', 'DigestAuth'), ('httpx._client', 'UseClientDefault'), ('httpx._client', 'ClientState'), ('httpx._client', 'BoundSyncStream'), ('httpx._client', 'BoundAsyncStream')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_http_url_headers_and_query_encoding():
    import httpx

    request = httpx.Request("GET", "https://example.test/items", params={"q": "a b"}, headers={"X-Test": "yes"})
    assert str(request.url) == "https://example.test/items?q=a+b"
    assert request.headers["x-test"] == "yes"
