from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'dominate'
CORE_MODULES = ['dominate', 'dominate.document', 'dominate.dom1core', 'dominate.dom_tag', 'dominate.svg', 'dominate.tags']
PUBLIC_SYMBOLS = [('dominate.document', 'document'), ('dominate.dom1core', 'dom1core'), ('dominate.dom_tag', 'dom_tag'), ('dominate.dom_tag', 'get_current'), ('dominate.dom_tag', 'attr'), ('dominate.svg', 'svg_tag'), ('dominate.svg', 'svg'), ('dominate.svg', 'animate'), ('dominate.svg', 'animateMotion'), ('dominate.svg', 'animateTransform'), ('dominate.svg', 'circle'), ('dominate.svg', 'clipPath'), ('dominate.svg', 'defs'), ('dominate.svg', 'desc'), ('dominate.svg', 'ellipse'), ('dominate.svg', 'g'), ('dominate.svg', 'image'), ('dominate.svg', 'line')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_html_tags_render_nested_content_and_attributes():
    from dominate.tags import div, span

    rendered = str(div(span("hello"), cls="box"))
    assert '<div class="box">' in rendered
    assert "<span>hello</span>" in rendered
    assert rendered.rstrip().endswith("</div>")
