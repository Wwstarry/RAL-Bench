"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_html_tags_render_nested_content_and_attributes():
    from dominate.tags import div, span

    rendered = str(div(span("hello"), cls="box"))
    assert '<div class="box">' in rendered
    assert "<span>hello</span>" in rendered
    assert rendered.rstrip().endswith("</div>")
