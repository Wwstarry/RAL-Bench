"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_html_tags_render_nested_content_and_attributes():
    from dominate.tags import div, span

    rendered = str(div(span("hello"), cls="box"))
    assert '<div class="box">' in rendered
    assert "<span>hello</span>" in rendered
    assert rendered.rstrip().endswith("</div>")
