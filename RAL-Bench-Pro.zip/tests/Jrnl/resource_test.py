"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_journal_entry_title_splitting_handles_sentences_and_newlines():
    from jrnl.journals.Entry import split_title

    assert split_title("First sentence. Remaining text") == ("First sentence.", "Remaining text")
    assert split_title("Title only") == ("Title only", "")
    assert split_title("Heading\nBody") == ("Heading", "Body")
