"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_journal_entry_title_splitting_handles_sentences_and_newlines():
    from jrnl.journals.Entry import split_title

    assert split_title("First sentence. Remaining text") == ("First sentence.", "Remaining text")
    assert split_title("Title only") == ("Title only", "")
    assert split_title("Heading\nBody") == ("Heading", "Body")
