from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jrnl'
CORE_MODULES = ['jrnl', 'jrnl.encryption', 'jrnl.journals', 'jrnl.messages', 'jrnl.plugins', 'jrnl.args']
PUBLIC_SYMBOLS = [('jrnl.encryption', 'EncryptionMethods'), ('jrnl.encryption', 'determine_encryption_method'), ('jrnl.plugins', 'get_exporter'), ('jrnl.plugins', 'get_importer'), ('jrnl.args', 'WrappingFormatter'), ('jrnl.args', 'IgnoreNoneAppendAction'), ('jrnl.args', 'parse_not_arg'), ('jrnl.args', 'parse_args')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_journal_entry_title_splitting_handles_sentences_and_newlines():
    from jrnl.journals.Entry import split_title

    assert split_title("First sentence. Remaining text") == ("First sentence.", "Remaining text")
    assert split_title("Title only") == ("Title only", "")
    assert split_title("Heading\nBody") == ("Heading", "Body")
