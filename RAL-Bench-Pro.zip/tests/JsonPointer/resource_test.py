"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_json_pointer_resolves_escaped_paths_and_defaults():
    import jsonpointer

    document = {"a/b": {"~key": [10, 20]}}
    assert jsonpointer.resolve_pointer(document, "/a~1b/~0key/1") == 20
    assert jsonpointer.resolve_pointer(document, "/missing", default="fallback") == "fallback"
