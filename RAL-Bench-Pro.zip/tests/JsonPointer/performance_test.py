"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_json_pointer_resolves_escaped_paths_and_defaults():
    import jsonpointer

    document = {"a/b": {"~key": [10, 20]}}
    assert jsonpointer.resolve_pointer(document, "/a~1b/~0key/1") == 20
    assert jsonpointer.resolve_pointer(document, "/missing", default="fallback") == "fallback"
