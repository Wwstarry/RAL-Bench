from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'jsonpointer'
CORE_MODULES = ['jsonpointer']
PUBLIC_SYMBOLS = [('jsonpointer', 'JsonPointerException'), ('jsonpointer', 'EndOfList'), ('jsonpointer', 'JsonPointer'), ('jsonpointer', 'set_pointer'), ('jsonpointer', 'resolve_pointer'), ('jsonpointer', 'pairwise'), ('jsonpointer', 'escape'), ('jsonpointer', 'unescape')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_json_pointer_resolves_escaped_paths_and_defaults():
    import jsonpointer

    document = {"a/b": {"~key": [10, 20]}}
    assert jsonpointer.resolve_pointer(document, "/a~1b/~0key/1") == 20
    assert jsonpointer.resolve_pointer(document, "/missing", default="fallback") == "fallback"
