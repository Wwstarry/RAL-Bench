"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_colcon_default_value_wrappers_round_trip_values():
    from colcon_core.argument_default import unwrap_default_value, wrap_default_value

    wrapped = wrap_default_value(["a", "b"])
    assert unwrap_default_value(wrapped) == ["a", "b"]
    with pytest.raises(ValueError):
        unwrap_default_value("plain")
