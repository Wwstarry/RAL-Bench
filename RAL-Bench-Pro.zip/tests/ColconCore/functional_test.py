from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'colcon_core'
CORE_MODULES = ['colcon_core', 'colcon_core.argument_parser', 'colcon_core.distutils', 'colcon_core.environment', 'colcon_core.event', 'colcon_core.event_handler']
PUBLIC_SYMBOLS = [('colcon_core.argument_parser', 'ArgumentParserDecoratorExtensionPoint'), ('colcon_core.argument_parser', 'ArgumentParserDecorator'), ('colcon_core.argument_parser', 'SuppressUsageOutput'), ('colcon_core.argument_parser', 'get_argument_parser_extensions'), ('colcon_core.argument_parser', 'decorate_argument_parser'), ('colcon_core.environment', 'EnvironmentExtensionPoint'), ('colcon_core.environment', 'get_environment_extensions'), ('colcon_core.environment', 'create_environment_scripts'), ('colcon_core.environment', 'create_environment_scripts_only'), ('colcon_core.environment', 'create_file_with_runtime_dependencies'), ('colcon_core.environment', 'create_environment_hooks'), ('colcon_core.event_handler', 'EventHandlerExtensionPoint'), ('colcon_core.event_handler', 'get_event_handler_extensions'), ('colcon_core.event_handler', 'add_event_handler_arguments'), ('colcon_core.event_handler', 'apply_event_handler_arguments'), ('colcon_core.event_handler', 'format_duration'), ('colcon_core.executor', 'Job'), ('colcon_core.executor', 'OnError')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_colcon_default_value_wrappers_round_trip_values():
    from colcon_core.argument_default import unwrap_default_value, wrap_default_value

    wrapped = wrap_default_value(["a", "b"])
    assert unwrap_default_value(wrapped) == ["a", "b"]
    with pytest.raises(ValueError):
        unwrap_default_value("plain")
