"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_colcon_default_value_wrappers_round_trip_values():
    from colcon_core.argument_default import unwrap_default_value, wrap_default_value

    wrapped = wrap_default_value(["a", "b"])
    assert unwrap_default_value(wrapped) == ["a", "b"]
    with pytest.raises(ValueError):
        unwrap_default_value("plain")
