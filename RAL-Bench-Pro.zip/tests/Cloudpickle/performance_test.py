"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_cloudpickle_round_trips_lambda_closure():
    import cloudpickle

    offset = 7
    function = lambda value: value + offset
    restored = cloudpickle.loads(cloudpickle.dumps(function))
    assert restored(5) == 12
