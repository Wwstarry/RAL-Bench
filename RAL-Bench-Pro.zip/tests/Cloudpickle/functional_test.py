from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'cloudpickle'
CORE_MODULES = ['cloudpickle', 'cloudpickle.cloudpickle']
PUBLIC_SYMBOLS = [('cloudpickle.cloudpickle', 'Pickler'), ('cloudpickle.cloudpickle', 'register_pickle_by_value'), ('cloudpickle.cloudpickle', 'unregister_pickle_by_value'), ('cloudpickle.cloudpickle', 'list_registry_pickle_by_value'), ('cloudpickle.cloudpickle', 'is_tornado_coroutine'), ('cloudpickle.cloudpickle', 'subimport'), ('cloudpickle.cloudpickle', 'dynamic_subimport'), ('cloudpickle.cloudpickle', 'instance'), ('cloudpickle.cloudpickle', 'dump'), ('cloudpickle.cloudpickle', 'dumps')]


def test_top_level_package_imports():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    assert REPO_ROOT == __import__("pathlib").Path(origin).resolve() or REPO_ROOT in __import__("pathlib").Path(origin).resolve().parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    module = importlib.import_module(module_name)
    assert module.__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert callable(value)
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_cloudpickle_round_trips_lambda_closure():
    import cloudpickle

    offset = 7
    function = lambda value: value + offset
    restored = cloudpickle.loads(cloudpickle.dumps(function))
    assert restored(5) == 12
