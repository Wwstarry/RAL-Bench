"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_cloudpickle_round_trips_lambda_closure():
    import cloudpickle

    offset = 7
    function = lambda value: value + offset
    restored = cloudpickle.loads(cloudpickle.dumps(function))
    assert restored(5) == 12
