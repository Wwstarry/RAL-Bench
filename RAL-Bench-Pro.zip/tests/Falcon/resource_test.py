"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_falcon_wsgi_route_returns_json_response():
    import falcon
    from falcon import testing

    class Resource:
        def on_get(self, req, resp):
            resp.media = {"ok": True}

    app = falcon.App()
    app.add_route("/health", Resource())
    result = testing.TestClient(app).simulate_get("/health")
    assert result.status_code == 200
    assert result.json == {"ok": True}
