"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_email_validation_normalizes_domain_without_network_lookup():
    from email_validator import validate_email

    result = validate_email("User@EXAMPLE.COM", check_deliverability=False)
    assert result.normalized == "User@example.com"
    assert result.ascii_domain == "example.com"
