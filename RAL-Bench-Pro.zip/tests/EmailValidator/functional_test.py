from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'email_validator'
CORE_MODULES = ['email_validator', 'email_validator.__main__', 'email_validator.deliverability', 'email_validator.exceptions', 'email_validator.syntax', 'email_validator.types']
PUBLIC_SYMBOLS = [('email_validator.__main__', 'main'), ('email_validator.deliverability', 'caching_resolver'), ('email_validator.deliverability', 'validate_email_deliverability'), ('email_validator.exceptions', 'EmailNotValidError'), ('email_validator.exceptions', 'EmailSyntaxError'), ('email_validator.exceptions', 'EmailUndeliverableError'), ('email_validator.syntax', 'LocalPartValidationResult'), ('email_validator.syntax', 'DomainNameValidationResult'), ('email_validator.syntax', 'DomainLiteralValidationResult'), ('email_validator.syntax', 'split_email'), ('email_validator.syntax', 'get_length_reason'), ('email_validator.syntax', 'safe_character_display'), ('email_validator.syntax', 'validate_email_local_part'), ('email_validator.syntax', 'check_unsafe_chars'), ('email_validator.syntax', 'check_dot_atom'), ('email_validator.syntax', 'uts46_valid_char'), ('email_validator.syntax', 'validate_email_domain_name'), ('email_validator.syntax', 'validate_email_length')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_email_validation_normalizes_domain_without_network_lookup():
    from email_validator import validate_email

    result = validate_email("User@EXAMPLE.COM", check_deliverability=False)
    assert result.normalized == "User@example.com"
    assert result.ascii_domain == "example.com"
