"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_eml_parser_extracts_headers_and_plain_text_body():
    from eml_parser import EmlParser

    raw = b"From: sender@example.com\r\nTo: user@example.com\r\nSubject: Demo\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nHello world"
    parsed = EmlParser(include_raw_body=True).decode_email_bytes(raw)
    assert parsed["header"]["subject"] == "Demo"
    assert parsed["body"][0]["content"].strip() == "Hello world"
