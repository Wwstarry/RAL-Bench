from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'eml_parser'
CORE_MODULES = ['eml_parser', 'eml_parser.decode', 'eml_parser.parser', 'eml_parser.routing']
PUBLIC_SYMBOLS = [('eml_parser.decode', 'decode_field'), ('eml_parser.decode', 'decode_string'), ('eml_parser.decode', 'workaround_bug_27257'), ('eml_parser.decode', 'workaround_field_value_parsing_errors'), ('eml_parser.decode', 'robust_string2date'), ('eml_parser.decode', 'json_serial'), ('eml_parser.decode', 'export_to_json'), ('eml_parser.decode', 'rfc2047_decode'), ('eml_parser.parser', 'CustomPolicy'), ('eml_parser.parser', 'EmlParser'), ('eml_parser.routing', 'noparenthesis'), ('eml_parser.routing', 'cleanline'), ('eml_parser.routing', 'get_domain_ip'), ('eml_parser.routing', 'parserouting')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_eml_parser_extracts_headers_and_plain_text_body():
    from eml_parser import EmlParser

    raw = b"From: sender@example.com\r\nTo: user@example.com\r\nSubject: Demo\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nHello world"
    parsed = EmlParser(include_raw_body=True).decode_email_bytes(raw)
    assert parsed["header"]["subject"] == "Demo"
    assert parsed["body"][0]["content"].strip() == "Hello world"
