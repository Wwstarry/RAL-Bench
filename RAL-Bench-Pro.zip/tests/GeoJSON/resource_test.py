"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_geojson_round_trips_features_and_coordinates():
    import geojson

    feature = geojson.Feature(geometry=geojson.Point((1.5, 2.5)), properties={"name": "demo"})
    restored = geojson.loads(geojson.dumps(feature))
    assert restored.geometry.coordinates == [1.5, 2.5]
    assert restored.properties["name"] == "demo"
