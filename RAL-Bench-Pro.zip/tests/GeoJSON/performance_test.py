"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_geojson_round_trips_features_and_coordinates():
    import geojson

    feature = geojson.Feature(geometry=geojson.Point((1.5, 2.5)), properties={"name": "demo"})
    restored = geojson.loads(geojson.dumps(feature))
    assert restored.geometry.coordinates == [1.5, 2.5]
    assert restored.properties["name"] == "demo"
