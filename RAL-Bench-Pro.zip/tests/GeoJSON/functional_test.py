from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'geojson'
CORE_MODULES = ['geojson', 'geojson.base', 'geojson.codec', 'geojson.examples', 'geojson.feature', 'geojson.geometry']
PUBLIC_SYMBOLS = [('geojson.base', 'GeoJSON'), ('geojson.codec', 'GeoJSONEncoder'), ('geojson.codec', 'dump'), ('geojson.codec', 'dumps'), ('geojson.codec', 'load'), ('geojson.codec', 'loads'), ('geojson.examples', 'SimpleWebFeature'), ('geojson.examples', 'create_simple_web_feature'), ('geojson.feature', 'Feature'), ('geojson.feature', 'FeatureCollection'), ('geojson.geometry', 'Geometry'), ('geojson.geometry', 'GeometryCollection'), ('geojson.geometry', 'Point'), ('geojson.geometry', 'MultiPoint'), ('geojson.geometry', 'LineString'), ('geojson.geometry', 'MultiLineString'), ('geojson.geometry', 'Polygon'), ('geojson.geometry', 'MultiPolygon')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_geojson_round_trips_features_and_coordinates():
    import geojson

    feature = geojson.Feature(geometry=geojson.Point((1.5, 2.5)), properties={"name": "demo"})
    restored = geojson.loads(geojson.dumps(feature))
    assert restored.geometry.coordinates == [1.5, 2.5]
    assert restored.properties["name"] == "demo"
