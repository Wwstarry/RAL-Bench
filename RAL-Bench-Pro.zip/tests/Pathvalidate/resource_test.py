"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_path_sanitization_removes_windows_reserved_characters():
    from pathvalidate import is_valid_filename, sanitize_filename

    sanitized = sanitize_filename('report:2025?.txt', platform="Windows")
    assert sanitized == "report2025.txt"
    assert is_valid_filename(sanitized, platform="Windows") is True
