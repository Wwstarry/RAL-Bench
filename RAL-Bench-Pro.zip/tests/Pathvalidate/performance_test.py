"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_path_sanitization_removes_windows_reserved_characters():
    from pathvalidate import is_valid_filename, sanitize_filename

    sanitized = sanitize_filename('report:2025?.txt', platform="Windows")
    assert sanitized == "report2025.txt"
    assert is_valid_filename(sanitized, platform="Windows") is True
