from __future__ import annotations

import importlib
import inspect

import pytest

from conftest import REPO_ROOT


PACKAGE = 'pathvalidate'
CORE_MODULES = ['pathvalidate', 'pathvalidate._base', 'pathvalidate._common', 'pathvalidate._const', 'pathvalidate._filename', 'pathvalidate._filepath']
PUBLIC_SYMBOLS = [('pathvalidate._base', 'BaseFile'), ('pathvalidate._base', 'AbstractValidator'), ('pathvalidate._base', 'AbstractSanitizer'), ('pathvalidate._base', 'BaseValidator'), ('pathvalidate._common', 'validate_pathtype'), ('pathvalidate._common', 'to_str'), ('pathvalidate._common', 'is_nt_abspath'), ('pathvalidate._common', 'is_null_string'), ('pathvalidate._common', 'validate_unprintable_char'), ('pathvalidate._common', 'replace_unprintable_char'), ('pathvalidate._common', 'replace_ansi_escape'), ('pathvalidate._common', 'normalize_platform'), ('pathvalidate._common', 'findall_to_str'), ('pathvalidate._common', 'truncate_str'), ('pathvalidate._const', 'Platform'), ('pathvalidate._filename', 'FileNameSanitizer'), ('pathvalidate._filename', 'FileNameValidator'), ('pathvalidate._filename', 'validate_filename')]


def test_top_level_package_imports_from_selected_repository():
    module = importlib.import_module(PACKAGE)
    assert module.__name__ == PACKAGE
    origin = getattr(module, "__file__", None)
    assert origin is not None
    path = __import__("pathlib").Path(origin).resolve()
    assert REPO_ROOT == path or REPO_ROOT in path.parents


@pytest.mark.parametrize("module_name", CORE_MODULES)
def test_core_module_imports(module_name: str):
    assert importlib.import_module(module_name).__name__ == module_name


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS)
def test_core_public_symbols_exist(module_name: str, symbol: str):
    module = importlib.import_module(module_name)
    assert hasattr(module, symbol), f"{module_name} must expose {symbol}"


@pytest.mark.parametrize("module_name,symbol", PUBLIC_SYMBOLS[:8])
def test_public_callable_metadata_is_introspectable(module_name: str, symbol: str):
    value = getattr(importlib.import_module(module_name), symbol)
    if callable(value):
        assert getattr(value, "__name__", symbol)
        try:
            inspect.signature(value)
        except (TypeError, ValueError):
            pass

def test_path_sanitization_removes_windows_reserved_characters():
    from pathvalidate import is_valid_filename, sanitize_filename

    sanitized = sanitize_filename('report:2025?.txt', platform="Windows")
    assert sanitized == "report2025.txt"
    assert is_valid_filename(sanitized, platform="Windows") is True
