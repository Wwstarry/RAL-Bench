"""Project-specific runtime workload.

The workload deliberately reuses the reference-validated public behavior instead of timing module introspection or an empty namespace.
"""

import pytest

def test_date_trigger_fires_exactly_once():
    from datetime import datetime, timezone
    from apscheduler.triggers.date import DateTrigger

    run_time = datetime(2025, 1, 2, 3, 4, tzinfo=timezone.utc)
    trigger = DateTrigger(run_time)
    assert trigger.next() == run_time
    assert trigger.next() is None
