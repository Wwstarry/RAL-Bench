"""Project-specific resource workload.

RSS and CPU are sampled while executing the same reference-validated public behavior used by the functional oracle.
"""

import pytest

def test_date_trigger_fires_exactly_once():
    from datetime import datetime, timezone
    from apscheduler.triggers.date import DateTrigger

    run_time = datetime(2025, 1, 2, 3, 4, tzinfo=timezone.utc)
    trigger = DateTrigger(run_time)
    assert trigger.next() == run_time
    assert trigger.next() is None
